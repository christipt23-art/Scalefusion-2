package com.brlnt.scalefusion;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

/** Small "enter the password" box used by other screens. Opens as soon as the right password is typed. */
final class PasscodePrompt {

    private PasscodePrompt() {
    }

    static void ask(final Activity activity, String title, final Runnable onSuccess) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        final EditText input = new EditText(activity);
        input.setHint("Password");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        FrameLayout box = new FrameLayout(activity);
        int pad = (int) KioskUtils.dp(activity, 24);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("OK", null)
                .setNegativeButton("Cancel", null)
                .create();
        final boolean[] accepted = {false};

        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!accepted[0] && s.length() >= PasscodeStore.MIN_LENGTH
                        && PasscodeStore.verify(activity, s.toString().trim())) {
                    accepted[0] = true;
                    dialog.dismiss();
                    onSuccess.run();
                }
            }
        });
        dialog.setOnShowListener(di -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    if (accepted[0]) {
                        return;
                    }
                    if (PasscodeStore.verify(activity, input.getText().toString().trim())) {
                        accepted[0] = true;
                        dialog.dismiss();
                        onSuccess.run();
                    } else {
                        input.setText("");
                        Toast.makeText(activity, "Incorrect passcode", Toast.LENGTH_SHORT).show();
                    }
                }));
        dialog.show();
    }
}
