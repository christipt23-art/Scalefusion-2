package com.brlnt.scalefusion;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Bluetooth manager: switch Bluetooth on / off, see paired devices, find and pair new ones.
 * The real Android Bluetooth settings only open from the three dots at the top.
 */
public class BluetoothActivity extends AppCompatActivity {

    private SwitchCompat btSwitch;
    private LinearLayout pairedList;
    private LinearLayout availableList;
    private TextView pairedEmpty;
    private TextView availableStatus;

    private boolean updatingSwitch = false;
    private boolean scanning = false;
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null) {
                return;
            }
            switch (action) {
                case BluetoothDevice.ACTION_FOUND: {
                    BluetoothDevice d = deviceFrom(intent);
                    if (d != null) {
                        found.put(d.getAddress(), d);
                        renderAvailable();
                    }
                    break;
                }
                case BluetoothAdapter.ACTION_DISCOVERY_STARTED:
                    scanning = true;
                    renderAvailable();
                    break;
                case BluetoothAdapter.ACTION_DISCOVERY_FINISHED:
                    scanning = false;
                    renderAvailable();
                    break;
                case BluetoothAdapter.ACTION_STATE_CHANGED: {
                    int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                    if (state == BluetoothAdapter.STATE_OFF || state == BluetoothAdapter.STATE_TURNING_OFF) {
                        found.clear();
                        scanning = false;
                    }
                    refresh();
                    if (state == BluetoothAdapter.STATE_ON) {
                        startScan();
                    }
                    break;
                }
                default: // bond state changed
                    refresh();
                    break;
            }
        }
    };

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                refresh();
                startScan();
            });

    private final ActivityResultLauncher<Intent> enableLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                refresh();
                startScan();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        KioskUtils.hideSystemStatusBar(this);
        KioskUtils.applyRootInsets(findViewById(R.id.bt_root));

        btSwitch = findViewById(R.id.bt_switch);
        pairedList = findViewById(R.id.paired_list);
        availableList = findViewById(R.id.available_list);
        pairedEmpty = findViewById(R.id.paired_empty);
        availableStatus = findViewById(R.id.available_status);

        findViewById(R.id.bt_back).setOnClickListener(v -> finish());
        findViewById(R.id.bt_refresh).setOnClickListener(v -> {
            refresh();
            startScan();
        });
        findViewById(R.id.bt_more).setOnClickListener(v -> {
            android.widget.PopupMenu menu = new android.widget.PopupMenu(this, v);
            menu.getMenu().add(0, 1, 0, "Bluetooth settings");
            menu.setOnMenuItemClickListener(item -> {
                openBluetoothSettings();
                return true;
            });
            menu.show();
        });

        btSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (!updatingSwitch) {
                switchBluetooth(checked);
            }
        });

        requestMissingPermissions();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onStop() {
        try {
            unregisterReceiver(receiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        stopScan();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        KioskUtils.hideSystemStatusBar(this);
        refresh();
        startScan();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
        KioskUtils.onWindowFocus(this, hasFocus);
    }

    // ------------------------------------------------------------------
    // Permissions
    // ------------------------------------------------------------------
    private boolean granted(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || granted(Manifest.permission.BLUETOOTH_CONNECT);
    }

    private boolean hasScanPermission() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? granted(Manifest.permission.BLUETOOTH_SCAN)
                : granted(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private void requestMissingPermissions() {
        List<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!granted(Manifest.permission.BLUETOOTH_CONNECT)) {
                missing.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (!granted(Manifest.permission.BLUETOOTH_SCAN)) {
                missing.add(Manifest.permission.BLUETOOTH_SCAN);
            }
        } else if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!missing.isEmpty()) {
            KioskApp.allowLeave = true; // the permission box is a system screen
            permissionLauncher.launch(missing.toArray(new String[0]));
        }
    }

    // ------------------------------------------------------------------
    // Adapter helpers
    // ------------------------------------------------------------------
    private BluetoothAdapter getAdapter() {
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        return manager == null ? null : manager.getAdapter();
    }

    @SuppressWarnings("deprecation")
    private BluetoothDevice deviceFrom(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
        }
        return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    }

    @SuppressLint("MissingPermission")
    private String nameOf(BluetoothDevice device) {
        String name = null;
        try {
            name = device.getName();
        } catch (SecurityException ignored) {
            // no permission: show the address instead
        }
        return name == null || name.isEmpty() ? device.getAddress() : name;
    }

    @SuppressLint("MissingPermission")
    private boolean isBonded(BluetoothDevice device) {
        try {
            return device.getBondState() == BluetoothDevice.BOND_BONDED;
        } catch (SecurityException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Switch on / off
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    private void switchBluetooth(boolean on) {
        BluetoothAdapter adapter = getAdapter();
        if (adapter == null) {
            setSwitch(false);
            return;
        }
        if (!hasConnectPermission()) {
            setSwitch(!on);
            requestMissingPermissions();
            return;
        }
        boolean done = false;
        try {
            done = on ? adapter.enable() : adapter.disable();
        } catch (RuntimeException ignored) {
            done = false; // newer Android versions refuse this for normal apps
        }
        if (done) {
            handler.postDelayed(this::refresh, 1000);
            return;
        }
        if (on) {
            // The standard "Allow to turn on Bluetooth?" box (it stays inside this app)
            setSwitch(false);
            KioskApp.allowLeave = true;
            try {
                enableLauncher.launch(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            } catch (RuntimeException e) {
                KioskApp.allowLeave = false;
                Toast.makeText(this, "Unable to turn Bluetooth on", Toast.LENGTH_SHORT).show();
            }
        } else {
            setSwitch(true);
            Toast.makeText(this, "Android does not let apps turn Bluetooth off. "
                    + "Use the three dots > Bluetooth settings.", Toast.LENGTH_LONG).show();
        }
    }

    private void setSwitch(boolean checked) {
        updatingSwitch = true;
        btSwitch.setChecked(checked);
        updatingSwitch = false;
    }

    // ------------------------------------------------------------------
    // Lists
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    private void refresh() {
        pairedList.removeAllViews();
        BluetoothAdapter adapter = getAdapter();

        if (adapter == null) {
            setSwitch(false);
            btSwitch.setEnabled(false);
            showEmpty("Bluetooth is not available on this device");
            renderAvailable();
            return;
        }

        setSwitch(adapter.isEnabled());

        if (!adapter.isEnabled()) {
            showEmpty("Bluetooth is off");
            renderAvailable();
            return;
        }
        if (!hasConnectPermission()) {
            showEmpty("Allow \"Nearby devices\" permission to see paired devices");
            renderAvailable();
            return;
        }

        Set<BluetoothDevice> bonded;
        try {
            bonded = adapter.getBondedDevices();
        } catch (SecurityException e) {
            showEmpty("Allow \"Nearby devices\" permission to see paired devices");
            renderAvailable();
            return;
        }

        if (bonded == null || bonded.isEmpty()) {
            showEmpty("No paired devices");
        } else {
            pairedEmpty.setVisibility(View.GONE);
            for (final BluetoothDevice device : bonded) {
                View row = getLayoutInflater().inflate(R.layout.item_paired_device, pairedList, false);
                ((TextView) row.findViewById(R.id.device_name)).setText(nameOf(device));
                row.findViewById(R.id.device_settings).setOnClickListener(v -> askForget(device));
                pairedList.addView(row);
            }
        }
        renderAvailable();
    }

    private void showEmpty(String message) {
        pairedEmpty.setText(message);
        pairedEmpty.setVisibility(View.VISIBLE);
    }

    @SuppressLint("MissingPermission")
    private void renderAvailable() {
        availableList.removeAllViews();
        BluetoothAdapter adapter = getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            availableStatus.setText("Turn Bluetooth on to find devices");
            availableStatus.setVisibility(View.VISIBLE);
            return;
        }
        if (!hasScanPermission()) {
            availableStatus.setText("Allow the permission to search for devices");
            availableStatus.setVisibility(View.VISIBLE);
            return;
        }

        int shown = 0;
        for (final BluetoothDevice device : found.values()) {
            if (isBonded(device)) {
                continue;
            }
            View row = getLayoutInflater().inflate(R.layout.item_paired_device, availableList, false);
            ((TextView) row.findViewById(R.id.device_name)).setText(nameOf(device));
            row.findViewById(R.id.device_settings).setVisibility(View.GONE);
            row.setOnClickListener(v -> pairWith(device));
            availableList.addView(row);
            shown++;
        }

        if (scanning) {
            availableStatus.setText("Searching for devices...");
            availableStatus.setVisibility(View.VISIBLE);
        } else if (shown == 0) {
            availableStatus.setText("No devices found. Tap refresh to search again.");
            availableStatus.setVisibility(View.VISIBLE);
        } else {
            availableStatus.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------
    // Scan, pair, forget
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    private void startScan() {
        BluetoothAdapter adapter = getAdapter();
        if (adapter == null || !adapter.isEnabled() || !hasScanPermission()) {
            renderAvailable();
            return;
        }
        try {
            if (adapter.isDiscovering()) {
                adapter.cancelDiscovery();
            }
            found.clear();
            scanning = adapter.startDiscovery();
        } catch (SecurityException e) {
            scanning = false;
        }
        renderAvailable();
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        try {
            BluetoothAdapter adapter = getAdapter();
            if (adapter != null && adapter.isEnabled() && hasScanPermission() && adapter.isDiscovering()) {
                adapter.cancelDiscovery();
            }
        } catch (SecurityException ignored) {
            // nothing to stop
        }
        scanning = false;
    }

    @SuppressLint("MissingPermission")
    private void pairWith(BluetoothDevice device) {
        if (!hasConnectPermission()) {
            requestMissingPermissions();
            return;
        }
        KioskApp.allowLeave = true; // the pairing box is a system screen
        try {
            stopScan();
            if (device.createBond()) {
                Toast.makeText(this, "Pairing with " + nameOf(device), Toast.LENGTH_SHORT).show();
            } else {
                KioskApp.allowLeave = false;
                Toast.makeText(this, "Unable to pair with " + nameOf(device), Toast.LENGTH_SHORT).show();
            }
        } catch (RuntimeException e) {
            KioskApp.allowLeave = false;
            Toast.makeText(this, "Unable to pair with this device", Toast.LENGTH_SHORT).show();
        }
    }

    private void askForget(final BluetoothDevice device) {
        new AlertDialog.Builder(this)
                .setTitle(nameOf(device))
                .setMessage("Forget this device?")
                .setPositiveButton("Forget", (d, w) -> forget(device))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void forget(BluetoothDevice device) {
        try {
            // Android hides this call from normal apps, so it can be refused
            Object result = device.getClass().getMethod("removeBond").invoke(device);
            if (Boolean.TRUE.equals(result)) {
                handler.postDelayed(this::refresh, 500);
                return;
            }
        } catch (Exception ignored) {
            // fall through
        }
        Toast.makeText(this, "Android does not let apps forget devices. "
                + "Use the three dots > Bluetooth settings.", Toast.LENGTH_LONG).show();
    }

    private void openBluetoothSettings() {
        KioskApp.allowLeave = true; // Settings is a system screen, not a Recents escape
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception e) {
            KioskApp.allowLeave = false;
            Toast.makeText(this, "Unable to open Bluetooth Settings", Toast.LENGTH_SHORT).show();
        }
    }
}
