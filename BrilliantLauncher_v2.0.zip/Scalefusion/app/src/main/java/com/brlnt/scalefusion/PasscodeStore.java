package com.brlnt.scalefusion;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * Keeps the device's own launcher password. It is chosen by the owner on the first launch, so every
 * device has a different one. Only a salted hash is stored (never the password itself).
 */
final class PasscodeStore {

    static final int MIN_LENGTH = 3;
    static final int MAX_LENGTH = 8;

    private static final String PREFS = "passcode_prefs";
    private static final String KEY_SALT = "salt";
    private static final String KEY_HASH = "hash";

    private PasscodeStore() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** True once the owner has chosen a password on this device. */
    static boolean isSet(Context c) {
        SharedPreferences p = prefs(c);
        String salt = p.getString(KEY_SALT, null);
        String hash = p.getString(KEY_HASH, null);
        return salt != null && !salt.isEmpty() && hash != null && !hash.isEmpty();
    }

    /** Returns an error message if the password is not acceptable, or null if it is fine. */
    static String validate(String code) {
        if (code == null || code.length() < MIN_LENGTH) {
            return "Password must be at least " + MIN_LENGTH + " digits";
        }
        if (code.length() > MAX_LENGTH) {
            return "Password can be at most " + MAX_LENGTH + " digits";
        }
        for (int i = 0; i < code.length(); i++) {
            if (!Character.isDigit(code.charAt(i))) {
                return "Use digits only";
            }
        }
        return null;
    }

    static boolean verify(Context c, String input) {
        if (input == null || !isSet(c)) {
            return false;
        }
        SharedPreferences p = prefs(c);
        try {
            byte[] salt = Base64.decode(p.getString(KEY_SALT, ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(p.getString(KEY_HASH, ""), Base64.NO_WRAP);
            return MessageDigest.isEqual(expected, hash(salt, input));
        } catch (Exception e) {
            return false;
        }
    }

    /** Saves a new password. Returns false if it could not be saved. */
    static boolean set(Context c, String code) {
        if (validate(code) != null) {
            return false;
        }
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            return prefs(c).edit()
                    .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString(KEY_HASH, Base64.encodeToString(hash(salt, code), Base64.NO_WRAP))
                    .commit();
        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] hash(byte[] salt, String code) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(salt);
        md.update(code.getBytes(StandardCharsets.UTF_8));
        return md.digest();
    }
}
