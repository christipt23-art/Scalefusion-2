package com.brlnt.scalefusion;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;

/** Plays the alarm / timer sound and shows the ringing screen. */
public class AlarmService extends Service {

    static final String ACTION_START = "com.brlnt.scalefusion.ALARM_START";
    static final String ACTION_STOP = "com.brlnt.scalefusion.ALARM_STOP";
    static final String ACTION_SNOOZE = "com.brlnt.scalefusion.ALARM_SNOOZE";
    /** Broadcast that tells the ringing screen to close. */
    static final String ACTION_FINISH_RING = "com.brlnt.scalefusion.FINISH_RING";

    private static final String CHANNEL_ID = "time_alarm";
    private static final int NOTIFICATION_ID = 4242;
    private static final long SNOOZE_MS = 10 * 60 * 1000L;
    private static final long AUTO_STOP_MS = 5 * 60 * 1000L;

    private Ringtone ringtone;
    private Vibrator vibrator;
    private String label = "Alarm";
    private int kind = AlarmScheduler.KIND_ALARM;
    private String ringtoneUri = null;
    private boolean vibrateOn = true;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = this::stopAll;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (ACTION_SNOOZE.equals(action)) {
            AlarmScheduler.scheduleSnooze(this, label, SNOOZE_MS, ringtoneUri, vibrateOn);
            stopAll();
            return START_NOT_STICKY;
        }
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        label = intent.getStringExtra(AlarmScheduler.EXTRA_LABEL);
        if (label == null) {
            label = "Alarm";
        }
        kind = intent.getIntExtra(AlarmScheduler.EXTRA_KIND, AlarmScheduler.KIND_ALARM);
        ringtoneUri = intent.getStringExtra(AlarmScheduler.EXTRA_RINGTONE);
        vibrateOn = intent.getBooleanExtra(AlarmScheduler.EXTRA_VIBRATE, true);

        Intent ring = new Intent(this, AlarmRingActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                .putExtra(AlarmScheduler.EXTRA_KIND, kind)
                .putExtra(AlarmScheduler.EXTRA_LABEL, label);

        Notification notification;
        try {
            notification = buildNotification(ring);
        } catch (RuntimeException e) {
            notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_alarm)
                    .setContentTitle(kind == AlarmScheduler.KIND_TIMER ? "Timer" : "Alarm")
                    .build();
        }
        try {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } catch (RuntimeException e) {
            try {
                startForeground(NOTIFICATION_ID, notification);
            } catch (RuntimeException ignored) {
                // give up on the foreground state, but keep ringing
            }
        }

        try {
            startRinging();
        } catch (RuntimeException e) {
            // a broken ringtone must never take the app down
        }
        try {
            startActivity(ring);
        } catch (RuntimeException ignored) {
            // The full-screen notification will show it instead
        }
        handler.removeCallbacks(autoStop);
        handler.postDelayed(autoStop, AUTO_STOP_MS);
        return START_NOT_STICKY;
    }

    private Notification buildNotification(Intent ring) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Alarms and timers",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(null, null); // the service plays the sound itself
        channel.enableVibration(false);
        nm.createNotificationChannel(channel);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent ringPi = PendingIntent.getActivity(this, 1, ring, piFlags);
        PendingIntent stopPi = PendingIntent.getService(this, 2,
                new Intent(this, AlarmService.class).setAction(ACTION_STOP), piFlags);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_alarm)
                .setContentTitle(kind == AlarmScheduler.KIND_TIMER ? "Timer" : "Alarm")
                .setContentText(label)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setFullScreenIntent(ringPi, true)
                .setContentIntent(ringPi)
                .addAction(R.drawable.ic_stop, "Dismiss", stopPi);
        if (kind != AlarmScheduler.KIND_TIMER) {
            PendingIntent snoozePi = PendingIntent.getService(this, 3,
                    new Intent(this, AlarmService.class).setAction(ACTION_SNOOZE), piFlags);
            b.addAction(R.drawable.ic_alarm, "Snooze", snoozePi);
        }
        return b.build();
    }

    private void startRinging() {
        stopSound();
        Uri uri = null;
        if (ringtoneUri != null && !ringtoneUri.isEmpty()) {
            try {
                uri = Uri.parse(ringtoneUri);
            } catch (RuntimeException e) {
                uri = null;
            }
        }
        if (uri == null) {
            uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
        }
        if (uri == null) {
            uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION);
        }
        if (uri == null) {
            uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE);
        }
        if (uri != null) {
            try {
                ringtone = RingtoneManager.getRingtone(this, uri);
                if (ringtone != null) {
                    ringtone.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build());
                    ringtone.setLooping(true);
                    ringtone.play();
                }
            } catch (RuntimeException e) {
                ringtone = null;
            }
        }
        try {
            vibrator = getSystemService(Vibrator.class);
            if (vibrator != null && vibrateOn) {
                vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 800, 800}, 0));
            }
        } catch (RuntimeException e) {
            vibrator = null;
        }
    }

    private void stopSound() {
        if (ringtone != null) {
            ringtone.stop();
            ringtone = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
            vibrator = null;
        }
    }

    private void stopAll() {
        handler.removeCallbacks(autoStop);
        stopSound();
        sendBroadcast(new Intent(ACTION_FINISH_RING).setPackage(getPackageName()));
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autoStop);
        stopSound();
        super.onDestroy();
    }
}
