package com.brlnt.scalefusion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

/** Called by the system when an alarm / timer / snooze time is reached. */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int kind = intent.getIntExtra(AlarmScheduler.EXTRA_KIND, AlarmScheduler.KIND_ALARM);
        int id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, -1);
        String label = intent.getStringExtra(AlarmScheduler.EXTRA_LABEL);
        String ringtone = intent.getStringExtra(AlarmScheduler.EXTRA_RINGTONE);
        boolean vibrate = intent.getBooleanExtra(AlarmScheduler.EXTRA_VIBRATE, true);

        if (kind == AlarmScheduler.KIND_ALARM) {
            Alarm alarm = AlarmStore.find(context, id);
            if (alarm == null || !alarm.enabled) {
                return;
            }
            label = alarm.label;
            ringtone = alarm.ringtone;   // always use the latest settings of the alarm
            vibrate = alarm.vibrate;
            if (alarm.days == 0) {
                // One-time alarm: switch it off after it rings
                alarm.enabled = false;
                AlarmStore.update(context, alarm);
            } else {
                // Repeating alarm: set the next one
                AlarmScheduler.schedule(context, alarm);
            }
        } else if (kind == AlarmScheduler.KIND_TIMER) {
            TimerState.reset(context);
            label = "Timer";
        }

        Intent service = new Intent(context, AlarmService.class)
                .setAction(AlarmService.ACTION_START)
                .putExtra(AlarmScheduler.EXTRA_KIND, kind)
                .putExtra(AlarmScheduler.EXTRA_LABEL, label == null ? "Alarm" : label)
                .putExtra(AlarmScheduler.EXTRA_RINGTONE, ringtone)
                .putExtra(AlarmScheduler.EXTRA_VIBRATE, vibrate);
        try {
            ContextCompat.startForegroundService(context, service);
        } catch (RuntimeException e) {
            // Could not start the service: show the ringing screen directly instead
            try {
                context.startActivity(new Intent(context, AlarmRingActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(AlarmScheduler.EXTRA_KIND, kind)
                        .putExtra(AlarmScheduler.EXTRA_LABEL, label == null ? "Alarm" : label));
            } catch (RuntimeException ignored) {
                // nothing more we can do
            }
        }
    }
}
