package com.brlnt.scalefusion;

import org.json.JSONException;
import org.json.JSONObject;

/** One alarm of the Time app. */
final class Alarm {
    int id;
    int hour;
    int minute;
    boolean enabled;
    /** Bit 0 = Sunday ... bit 6 = Saturday. 0 means "ring once". */
    int days;
    String label = "Alarm";
    /** Ringtone Uri as text, or null for the tablet's default alarm sound. */
    String ringtone = null;
    boolean vibrate = true;

    Alarm() {
    }

    Alarm(int id, int hour, int minute, boolean enabled, int days, String label) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.enabled = enabled;
        this.days = days;
        this.label = label;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("hour", hour);
        o.put("minute", minute);
        o.put("enabled", enabled);
        o.put("days", days);
        o.put("label", label);
        if (ringtone != null) {
            o.put("ringtone", ringtone);
        }
        o.put("vibrate", vibrate);
        return o;
    }

    static Alarm fromJson(JSONObject o) {
        Alarm a = new Alarm();
        a.id = o.optInt("id");
        a.hour = o.optInt("hour");
        a.minute = o.optInt("minute");
        a.enabled = o.optBoolean("enabled");
        a.days = o.optInt("days");
        a.label = o.optString("label", "Alarm");
        a.ringtone = o.has("ringtone") ? o.optString("ringtone", null) : null;
        a.vibrate = o.optBoolean("vibrate", true);
        return a;
    }
}
