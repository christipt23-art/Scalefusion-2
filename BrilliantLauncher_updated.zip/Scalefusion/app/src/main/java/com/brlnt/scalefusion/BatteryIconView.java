package com.brlnt.scalefusion;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Horizontal battery icon (like the Android status bar): outline, level fill, small tip. */
public class BatteryIconView extends View {

    private final Paint outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF body = new RectF();
    private final RectF tip = new RectF();
    private final RectF fill = new RectF();
    private int level = 100;
    private boolean charging = false;

    public BatteryIconView(Context context) {
        this(context, null);
    }

    public BatteryIconView(Context context, AttributeSet attrs) {
        super(context, attrs);
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setColor(Color.argb(170, 255, 255, 255));
        fillPaint.setStyle(Paint.Style.FILL);
        tipPaint.setStyle(Paint.Style.FILL);
        tipPaint.setColor(Color.argb(170, 255, 255, 255));
        updateFillColor();
    }

    public void setLevel(int percent) {
        int clamped = Math.max(0, Math.min(100, percent));
        if (clamped != level) {
            level = clamped;
            updateFillColor();
            invalidate();
        }
    }

    public void setCharging(boolean charging) {
        if (this.charging != charging) {
            this.charging = charging;
            updateFillColor();
            invalidate();
        }
    }

    private void updateFillColor() {
        if (charging) {
            fillPaint.setColor(Color.rgb(102, 217, 120));
        } else if (level <= 15) {
            fillPaint.setColor(Color.rgb(255, 82, 82));
        } else {
            fillPaint.setColor(Color.WHITE);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float stroke = Math.max(1f, h * 0.09f);
        outlinePaint.setStrokeWidth(stroke);

        float tipW = w * 0.09f;
        float r = h * 0.16f;
        float half = stroke / 2f;

        body.set(half, half, w - tipW - half, h - half);
        canvas.drawRoundRect(body, r, r, outlinePaint);

        tip.set(w - tipW, h * 0.32f, w, h * 0.68f);
        canvas.drawRoundRect(tip, tipW / 2, tipW / 2, tipPaint);

        float pad = stroke * 1.6f;
        float innerL = body.left + pad;
        float innerR = body.right - pad;
        float innerW = innerR - innerL;
        fill.set(innerL, body.top + pad, innerL + innerW * level / 100f, body.bottom - pad);
        if (fill.width() > 0) {
            canvas.drawRoundRect(fill, r / 2, r / 2, fillPaint);
        }
    }
}
