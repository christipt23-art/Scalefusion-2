package com.brlnt.scalefusion;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * "Wi-Fi Settings" screen: on/off switch, list of networks and a SCAN button.
 * The three dots at the top open the real Android Wi-Fi settings.
 */
public class WifiActivity extends AppCompatActivity {

    private WifiManager wifi;
    private SwitchCompat wifiSwitch;
    private LinearLayout list;
    private TextView empty;
    private boolean updatingSwitch = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refresh();
        }
    };

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                refresh();
                if (granted) {
                    startScanSafely();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        KioskUtils.hideSystemStatusBar(this);
        setContentView(R.layout.activity_wifi);
        KioskUtils.applyRootInsets(findViewById(R.id.wifi_root));

        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiSwitch = findViewById(R.id.wifi_switch);
        list = findViewById(R.id.wifi_list);
        empty = findViewById(R.id.wifi_empty);

        findViewById(R.id.wifi_back).setOnClickListener(v -> finish());
        findViewById(R.id.wifi_scan).setOnClickListener(v -> {
            if (wifi != null && wifi.isWifiEnabled()) {
                Toast.makeText(this, "Scanning...", Toast.LENGTH_SHORT).show();
            }
            startScanSafely();
            refresh();
        });
        findViewById(R.id.wifi_more).setOnClickListener(v -> {
            PopupMenu menu = new PopupMenu(this, v);
            menu.getMenu().add(0, 1, 0, "Open Wi-Fi settings");
            menu.setOnMenuItemClickListener(item -> {
                openRealWifiSettings();
                return true;
            });
            menu.show();
        });
        wifiSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (!updatingSwitch) {
                switchWifi(checked);
            }
        });

        if (!hasScanPermission()) {
            KioskApp.allowLeave = true; // the permission box is a system screen
            permissionLauncher.launch(scanPermission());
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        ContextCompat.registerReceiver(this, stateReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onStop() {
        try {
            unregisterReceiver(stateReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        KioskUtils.hideSystemStatusBar(this);
        refresh();
        startScanSafely();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
        KioskUtils.onWindowFocus(this, hasFocus);
    }

    // ------------------------------------------------------------------
    // Permission, scan, switch
    // ------------------------------------------------------------------
    private String scanPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.NEARBY_WIFI_DEVICES
                : Manifest.permission.ACCESS_FINE_LOCATION;
    }

    private boolean hasScanPermission() {
        return checkSelfPermission(scanPermission()) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressWarnings("deprecation")
    private void startScanSafely() {
        try {
            if (wifi != null && wifi.isWifiEnabled() && hasScanPermission()) {
                wifi.startScan();
            }
        } catch (RuntimeException ignored) {
            // scanning is throttled / refused: the latest results are shown instead
        }
    }

    @SuppressWarnings("deprecation")
    private void switchWifi(boolean on) {
        boolean done = false;
        try {
            done = wifi != null && wifi.setWifiEnabled(on);
        } catch (RuntimeException ignored) {
            done = false;
        }
        if (!done) {
            // Android does not let normal apps flip Wi-Fi: show the system Wi-Fi panel instead
            updatingSwitch = true;
            wifiSwitch.setChecked(!on);
            updatingSwitch = false;
            KioskApp.allowLeave = true;
            try {
                startActivity(new Intent(Settings.Panel.ACTION_WIFI));
            } catch (RuntimeException e) {
                KioskApp.allowLeave = false;
                openRealWifiSettings();
            }
        } else {
            handler.postDelayed(this::refresh, 800);
        }
    }

    private void openRealWifiSettings() {
        KioskApp.allowLeave = true; // Settings is a system screen, not a Recents escape
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (RuntimeException e) {
            KioskApp.allowLeave = false;
            Toast.makeText(this, "Unable to open Wi-Fi settings", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // The list
    // ------------------------------------------------------------------
    private static String clean(String ssid) {
        if (ssid == null) {
            return "";
        }
        if (ssid.length() >= 2 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
            return ssid.substring(1, ssid.length() - 1);
        }
        return ssid;
    }

    private static boolean isSecured(ScanResult r) {
        String c = r.capabilities == null ? "" : r.capabilities;
        return c.contains("WEP") || c.contains("PSK") || c.contains("EAP") || c.contains("SAE");
    }

    @SuppressWarnings("deprecation")
    private String currentSsid() {
        try {
            if (wifi != null && wifi.getConnectionInfo() != null
                    && wifi.getConnectionInfo().getNetworkId() != -1) {
                String s = clean(wifi.getConnectionInfo().getSSID());
                return "<unknown ssid>".equals(s) ? "" : s;
            }
        } catch (RuntimeException ignored) {
            // no access
        }
        return "";
    }

    private void showEmpty(String message) {
        empty.setText(message);
        empty.setVisibility(View.VISIBLE);
    }

    @SuppressWarnings("deprecation")
    private void refresh() {
        if (list == null) {
            return;
        }
        list.removeAllViews();
        empty.setVisibility(View.GONE);

        if (wifi == null) {
            updatingSwitch = true;
            wifiSwitch.setChecked(false);
            wifiSwitch.setEnabled(false);
            updatingSwitch = false;
            showEmpty("Wi-Fi is not available on this device");
            return;
        }
        boolean on = wifi.isWifiEnabled();
        updatingSwitch = true;
        wifiSwitch.setChecked(on);
        updatingSwitch = false;
        if (!on) {
            showEmpty("Wi-Fi is off");
            return;
        }
        if (!hasScanPermission()) {
            showEmpty("Allow the permission to see Wi-Fi networks");
            return;
        }

        List<ScanResult> results = new ArrayList<>();
        try {
            List<ScanResult> found = wifi.getScanResults();
            if (found != null) {
                results.addAll(found);
            }
        } catch (RuntimeException ignored) {
            // no access to scan results
        }

        final Set<String> saved = new HashSet<>();
        try {
            List<WifiConfiguration> configured = wifi.getConfiguredNetworks();
            if (configured != null) {
                for (WifiConfiguration c : configured) {
                    saved.add(clean(c.SSID));
                }
            }
        } catch (RuntimeException ignored) {
            // Android only shows an app the networks it created
        }

        final String current = currentSsid();

        // One row per network name, keeping the strongest signal
        Map<String, ScanResult> best = new LinkedHashMap<>();
        for (ScanResult r : results) {
            String name = r.SSID == null ? "" : r.SSID;
            if (name.isEmpty()) {
                continue;
            }
            ScanResult old = best.get(name);
            if (old == null || r.level > old.level) {
                best.put(name, r);
            }
        }
        List<ScanResult> rows = new ArrayList<>(best.values());
        Collections.sort(rows, (x, y) -> {
            int rx = x.SSID.equals(current) ? 0 : saved.contains(x.SSID) ? 1 : 2;
            int ry = y.SSID.equals(current) ? 0 : saved.contains(y.SSID) ? 1 : 2;
            if (rx != ry) {
                return rx - ry;
            }
            return y.level - x.level;
        });

        if (rows.isEmpty()) {
            showEmpty("No Wi-Fi networks found.\nTap SCAN to search again.");
            return;
        }

        for (ScanResult r : rows) {
            final String name = r.SSID;
            final boolean secured = isSecured(r);
            final boolean isSaved = saved.contains(name);
            final boolean connected = name.equals(current);

            View row = getLayoutInflater().inflate(R.layout.item_wifi, list, false);
            ((TextView) row.findViewById(R.id.wifi_name)).setText(name);
            String status;
            if (connected) {
                status = "Connected";
            } else if (isSaved) {
                status = secured ? "Saved, secured" : "Saved";
            } else {
                status = secured ? "Secured" : "Open";
            }
            ((TextView) row.findViewById(R.id.wifi_status)).setText(status);

            ImageView icon = row.findViewById(R.id.wifi_icon);
            int level = 4;
            try {
                level = wifi.calculateSignalLevel(r.level);
            } catch (RuntimeException ignored) {
                // keep full strength
            }
            icon.setColorFilter(connected ? 0xFF2F63C7 : 0xFF1F2A5E, PorterDuff.Mode.SRC_IN);
            icon.setAlpha(0.45f + 0.1375f * Math.max(0, Math.min(4, level)));

            row.findViewById(R.id.wifi_row).setOnClickListener(v ->
                    onNetworkClicked(name, secured, isSaved, connected));
            list.addView(row);
        }
    }

    // ------------------------------------------------------------------
    // Connecting
    // ------------------------------------------------------------------
    private void onNetworkClicked(String ssid, boolean secured, boolean saved, boolean connected) {
        if (connected) {
            return;
        }
        if (saved && connectSaved(ssid)) {
            return;
        }
        if (secured) {
            askPassword(ssid);
        } else {
            connectNew(ssid, null);
        }
    }

    @SuppressWarnings("deprecation")
    private boolean connectSaved(String ssid) {
        try {
            List<WifiConfiguration> configured = wifi.getConfiguredNetworks();
            if (configured != null) {
                for (WifiConfiguration c : configured) {
                    if (clean(c.SSID).equals(ssid)) {
                        if (wifi.enableNetwork(c.networkId, true)) {
                            Toast.makeText(this, "Connecting to " + ssid, Toast.LENGTH_SHORT).show();
                            handler.postDelayed(this::refresh, 2500);
                            return true;
                        }
                    }
                }
            }
        } catch (RuntimeException ignored) {
            // fall through
        }
        return false;
    }

    private void askPassword(final String ssid) {
        final EditText input = new EditText(this);
        input.setHint("Password");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        FrameLayout box = new FrameLayout(this);
        int pad = (int) KioskUtils.dp(this, 24);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle(ssid)
                .setView(box)
                .setPositiveButton("Connect", (d, w) -> {
                    String pass = input.getText().toString();
                    if (pass.length() < 8) {
                        Toast.makeText(this, "Password must be at least 8 characters",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        connectNew(ssid, pass);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @SuppressWarnings("deprecation")
    private void connectNew(String ssid, String password) {
        try {
            WifiConfiguration config = new WifiConfiguration();
            config.SSID = "\"" + ssid + "\"";
            if (password == null) {
                config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            } else {
                config.preSharedKey = "\"" + password + "\"";
            }
            int id = wifi.addNetwork(config);
            if (id != -1 && wifi.enableNetwork(id, true)) {
                wifi.reconnect();
                Toast.makeText(this, "Connecting to " + ssid, Toast.LENGTH_SHORT).show();
                handler.postDelayed(this::refresh, 2500);
                return;
            }
        } catch (RuntimeException ignored) {
            // fall through to the system screen
        }
        // Android does not let normal apps join networks: hand over to the real Wi-Fi settings
        Toast.makeText(this, "Opening Wi-Fi settings to connect", Toast.LENGTH_SHORT).show();
        openRealWifiSettings();
    }
}
