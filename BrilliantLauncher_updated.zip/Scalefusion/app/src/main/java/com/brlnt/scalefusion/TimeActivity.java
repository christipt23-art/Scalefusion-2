package com.brlnt.scalefusion;

import android.Manifest;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** The "Time" app: alarm, clock, timer and stopwatch on blue screens. */
public class TimeActivity extends AppCompatActivity {

    private static final int TAB_ALARM = 0;
    private static final int TAB_CLOCK = 1;
    private static final int TAB_TIMER = 2;
    private static final int TAB_STOPWATCH = 3;

    private static final String[] DAY_SHORT = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    private static final String[] DAY_LETTER = {"S", "M", "T", "W", "T", "F", "S"};

    // Kept in statics so the screen survives rotation
    private static int currentTab = TAB_ALARM;
    private static int expandedAlarmId = -1;
    private static String timerDigits = "";
    private static boolean swRunning = false;
    private static long swStartElapsed = 0;
    private static long swAccumulated = 0;
    private static final List<Long> swLaps = new ArrayList<>();

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tick();
            // fast refresh only for the stopwatch hundredths, slow otherwise (saves battery)
            handler.postDelayed(this, currentTab == TAB_STOPWATCH ? 50 : 250);
        }
    };

    private View[] pages;
    private ImageView[] tabs;
    private ImageView fab;

    private LinearLayout alarmList;
    private TextView clockTime;
    private TextView clockAmPm;
    private TextView clockDate;
    private View timerInput;
    private View timerRunning;
    private TextView timerDisplay;
    private TextView timerRemaining;
    private TextView swDisplay;
    private TextView swReset;
    private TextView swLap;
    private LinearLayout swLapList;

    private String lastClockText = "";
    private int lastTimerState = -1;

    private final ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        KioskUtils.hideSystemStatusBar(this);
        setContentView(R.layout.activity_time);
        KioskUtils.applyRootInsets(findViewById(R.id.time_root));

        pages = new View[]{
                findViewById(R.id.page_alarm), findViewById(R.id.page_clock),
                findViewById(R.id.page_timer), findViewById(R.id.page_stopwatch)};
        tabs = new ImageView[]{
                findViewById(R.id.tab_alarm), findViewById(R.id.tab_clock),
                findViewById(R.id.tab_timer), findViewById(R.id.tab_stopwatch)};
        fab = findViewById(R.id.time_fab);

        alarmList = findViewById(R.id.alarm_list);
        clockTime = findViewById(R.id.clock_time);
        clockAmPm = findViewById(R.id.clock_ampm);
        clockDate = findViewById(R.id.clock_date);
        timerInput = findViewById(R.id.timer_input);
        timerRunning = findViewById(R.id.timer_running);
        timerDisplay = findViewById(R.id.timer_display);
        timerRemaining = findViewById(R.id.timer_remaining);
        swDisplay = findViewById(R.id.sw_display);
        swReset = findViewById(R.id.sw_reset);
        swLap = findViewById(R.id.sw_lap);
        swLapList = findViewById(R.id.sw_laps);

        for (int i = 0; i < tabs.length; i++) {
            final int tab = i;
            tabs[i].setOnClickListener(v -> selectTab(tab));
        }
        fab.setOnClickListener(v -> onFabClicked());

        setupTimerKeypad();
        findViewById(R.id.timer_cancel).setOnClickListener(v -> {
            TimerState.reset(this);
            refreshTimerPage();
            updateFab();
        });
        swReset.setOnClickListener(v -> resetStopwatch());
        swLap.setOnClickListener(v -> lapStopwatch());

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            KioskApp.allowLeave = true; // the permission box is a system screen
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        renderAlarms();
        renderLaps();
        selectTab(currentTab);
    }

    @Override
    protected void onResume() {
        super.onResume();
        KioskUtils.hideSystemStatusBar(this);
        handler.post(ticker);
        renderAlarms();
        refreshTimerPage();
        updateFab();
    }

    @Override
    protected void onPause() {
        stopPreview();
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
        KioskUtils.onWindowFocus(this, hasFocus);
    }

    // ------------------------------------------------------------------
    // Tabs and the red round button
    // ------------------------------------------------------------------
    private void selectTab(int tab) {
        currentTab = tab;
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == tab ? View.VISIBLE : View.GONE);
            tabs[i].setAlpha(i == tab ? 1f : 0.5f);
        }
        refreshTimerPage();
        updateFab();
        tick();
    }

    private void updateFab() {
        switch (currentTab) {
            case TAB_ALARM:
                fab.setImageResource(R.drawable.ic_add);
                fab.setVisibility(View.VISIBLE);
                break;
            case TAB_CLOCK:
                fab.setImageResource(R.drawable.ic_globe);
                fab.setVisibility(View.VISIBLE);
                break;
            case TAB_TIMER:
                int st = TimerState.state(this);
                if (st == TimerState.IDLE) {
                    fab.setImageResource(R.drawable.ic_play);
                    fab.setVisibility(timerTotalMs() > 0 ? View.VISIBLE : View.GONE);
                } else {
                    fab.setImageResource(st == TimerState.RUNNING ? R.drawable.ic_pause : R.drawable.ic_play);
                    fab.setVisibility(View.VISIBLE);
                }
                break;
            default:
                fab.setImageResource(swRunning ? R.drawable.ic_pause : R.drawable.ic_play);
                fab.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void onFabClicked() {
        switch (currentTab) {
            case TAB_ALARM:
                addAlarm();
                break;
            case TAB_CLOCK:
                showWorldClocks();
                break;
            case TAB_TIMER:
                onTimerFab();
                break;
            default:
                toggleStopwatch();
                break;
        }
    }

    // ------------------------------------------------------------------
    // Ticking (updates whichever page is visible)
    // ------------------------------------------------------------------
    private void tick() {
        if (currentTab == TAB_CLOCK) {
            updateClockPage();
        } else if (currentTab == TAB_TIMER) {
            int st = TimerState.state(this);
            if (st != lastTimerState) {
                lastTimerState = st;
                refreshTimerPage();
                updateFab();
            } else if (st == TimerState.RUNNING) {
                timerRemaining.setText(formatRemaining(TimerState.remainingMs(this)));
            }
        } else if (currentTab == TAB_STOPWATCH) {
            swDisplay.setText(stopwatchText(stopwatchElapsed()));
        }
    }

    // ------------------------------------------------------------------
    // Alarm tab
    // ------------------------------------------------------------------
    private boolean is24h() {
        return DateFormat.is24HourFormat(this);
    }

    private void renderAlarms() {
        alarmList.removeAllViews();
        final List<Alarm> alarms = AlarmStore.load(this);
        for (final Alarm a : alarms) {
            View row = getLayoutInflater().inflate(R.layout.item_alarm, alarmList, false);
            View card = row.findViewById(R.id.alarm_card);
            TextView time = row.findViewById(R.id.alarm_time);
            TextView ampm = row.findViewById(R.id.alarm_ampm);
            TextView summary = row.findViewById(R.id.alarm_summary);
            SwitchCompat sw = row.findViewById(R.id.alarm_switch);
            ImageView expand = row.findViewById(R.id.alarm_expand);
            View expanded = row.findViewById(R.id.alarm_expanded);
            CheckBox repeat = row.findViewById(R.id.alarm_repeat);
            LinearLayout dayRow = row.findViewById(R.id.alarm_days);
            View ringtoneRow = row.findViewById(R.id.alarm_ringtone_row);
            TextView ringtoneName = row.findViewById(R.id.alarm_ringtone);
            CheckBox vibrate = row.findViewById(R.id.alarm_vibrate);
            TextView labelView = row.findViewById(R.id.alarm_label);
            View delete = row.findViewById(R.id.alarm_delete);

            if (is24h()) {
                time.setText(String.format(Locale.US, "%02d:%02d", a.hour, a.minute));
                ampm.setText("");
            } else {
                int h12 = a.hour % 12 == 0 ? 12 : a.hour % 12;
                time.setText(String.format(Locale.US, "%d:%02d", h12, a.minute));
                ampm.setText(a.hour < 12 ? "am" : "pm");
            }
            summary.setText(summaryText(a));
            labelView.setText(a.label == null || a.label.isEmpty() ? "Label" : a.label);
            ringtoneName.setText(ringtoneTitle(a));

            sw.setChecked(a.enabled);
            sw.setOnCheckedChangeListener((button, checked) -> {
                a.enabled = checked;
                AlarmStore.update(this, a);
                long t = AlarmScheduler.apply(this, a);
                if (checked && t > 0) {
                    Toast.makeText(this, "Alarm set for " + describeUntil(t - System.currentTimeMillis()),
                            Toast.LENGTH_SHORT).show();
                }
            });

            // Tap the card to open / close the edit screen; tap the time again to change it
            final boolean isOpen = expandedAlarmId == a.id;
            expanded.setVisibility(isOpen ? View.VISIBLE : View.GONE);
            expand.setRotation(isOpen ? 180f : 0f);
            card.setOnClickListener(v -> {
                expandedAlarmId = expandedAlarmId == a.id ? -1 : a.id;
                renderAlarms();
            });
            time.setOnClickListener(v -> {
                if (expandedAlarmId == a.id) {
                    showTimePicker(a.hour, a.minute, (picker, hour, minute) -> {
                        a.hour = hour;
                        a.minute = minute;
                        a.enabled = true;
                        AlarmStore.update(this, a);
                        long t = AlarmScheduler.apply(this, a);
                        renderAlarms();
                        if (t > 0) {
                            Toast.makeText(this, "Alarm set for "
                                    + describeUntil(t - System.currentTimeMillis()), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    expandedAlarmId = a.id;
                    renderAlarms();
                }
            });

            // Repeat + day circles
            repeat.setChecked(a.days != 0);
            dayRow.setVisibility(a.days != 0 ? View.VISIBLE : View.GONE);
            repeat.setOnCheckedChangeListener((button, checked) -> {
                a.days = checked ? (a.days == 0 ? 0b0111110 : a.days) : 0; // Mon-Fri by default
                saveAlarm(a);
                renderAlarms();
            });
            for (int d = 0; d < 7; d++) {
                final int day = d;
                boolean on = ((a.days >> d) & 1) == 1;
                TextView chip = new TextView(this);
                chip.setText(DAY_LETTER[d]);
                chip.setGravity(Gravity.CENTER);
                chip.setTextSize(14);
                chip.setTextColor(on ? getColor(R.color.time_blue) : Color.WHITE);
                chip.setBackgroundResource(on ? R.drawable.bg_day_on : R.drawable.bg_day_off);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) KioskUtils.dp(this, 40), 1f);
                lp.setMargins(4, 0, 4, 0);
                dayRow.addView(chip, lp);
                chip.setOnClickListener(v -> {
                    a.days ^= (1 << day);
                    saveAlarm(a);
                    renderAlarms();
                });
            }

            // Ringtone, vibrate, label, delete
            ringtoneRow.setOnClickListener(v -> showRingtonePicker(a));
            vibrate.setChecked(a.vibrate);
            vibrate.setOnCheckedChangeListener((button, checked) -> {
                a.vibrate = checked;
                saveAlarm(a);
            });
            labelView.setOnClickListener(v -> editLabel(a));
            delete.setOnClickListener(v -> {
                AlarmScheduler.cancel(this, a);
                List<Alarm> all = AlarmStore.load(this);
                for (int i = all.size() - 1; i >= 0; i--) {
                    if (all.get(i).id == a.id) {
                        all.remove(i);
                    }
                }
                AlarmStore.save(this, all);
                expandedAlarmId = -1;
                renderAlarms();
            });

            alarmList.addView(row);
        }
    }

    /** Saves the alarm and sets / cancels the system alarm to match. */
    private void saveAlarm(Alarm a) {
        AlarmStore.update(this, a);
        AlarmScheduler.apply(this, a);
    }

    private Uri defaultAlarmUri() {
        Uri uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
        return uri != null ? uri : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    }

    private String ringtoneTitle(Alarm a) {
        try {
            Uri uri = a.ringtone == null ? defaultAlarmUri() : Uri.parse(a.ringtone);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) {
                String title = r.getTitle(this);
                if (title != null && !title.isEmpty()) {
                    return title;
                }
            }
        } catch (RuntimeException ignored) {
            // fall through
        }
        return "Default alarm sound";
    }

    private Ringtone previewRingtone;

    private void stopPreview() {
        if (previewRingtone != null) {
            try {
                previewRingtone.stop();
            } catch (RuntimeException ignored) {
                // already stopped
            }
            previewRingtone = null;
        }
    }

    private void playPreview(String uriText) {
        stopPreview();
        try {
            Uri uri = uriText == null ? defaultAlarmUri() : Uri.parse(uriText);
            previewRingtone = RingtoneManager.getRingtone(this, uri);
            if (previewRingtone != null) {
                previewRingtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
                previewRingtone.play();
            }
        } catch (RuntimeException ignored) {
            previewRingtone = null;
        }
    }

    /** Lists the tablet's alarm sounds; tapping one plays it, OK keeps it. */
    private void showRingtonePicker(final Alarm a) {
        final List<String> titles = new ArrayList<>();
        final List<String> uris = new ArrayList<>();
        titles.add("Default alarm sound");
        uris.add(null);
        try {
            RingtoneManager manager = new RingtoneManager(this);
            manager.setType(RingtoneManager.TYPE_ALARM);
            Cursor c = manager.getCursor();
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        titles.add(c.getString(RingtoneManager.TITLE_COLUMN_INDEX));
                        Uri base = Uri.parse(c.getString(RingtoneManager.URI_COLUMN_INDEX));
                        uris.add(ContentUris.withAppendedId(base,
                                c.getLong(RingtoneManager.ID_COLUMN_INDEX)).toString());
                    }
                } finally {
                    c.close();
                }
            }
        } catch (RuntimeException ignored) {
            // only the default sound is offered
        }

        int checked = 0;
        for (int i = 1; i < uris.size(); i++) {
            if (uris.get(i).equals(a.ringtone)) {
                checked = i;
            }
        }
        final int[] selected = {checked};
        new AlertDialog.Builder(this)
                .setTitle("Alarm sound")
                .setSingleChoiceItems(titles.toArray(new String[0]), checked, (d, which) -> {
                    selected[0] = which;
                    playPreview(uris.get(which));
                })
                .setPositiveButton("OK", (d, w) -> {
                    a.ringtone = uris.get(selected[0]);
                    saveAlarm(a);
                    renderAlarms();
                })
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(d -> stopPreview())
                .show();
    }

    private CharSequence summaryText(Alarm a) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        sb.append(a.label == null || a.label.isEmpty() ? "Alarm" : a.label);
        sb.append("  ");
        int start = sb.length();
        if (a.days == 0) {
            sb.append("Once");
        } else if (a.days == 0b1111111) {
            sb.append("Every day");
        } else {
            boolean first = true;
            for (int d = 0; d < 7; d++) {
                if (((a.days >> d) & 1) == 1) {
                    if (!first) {
                        sb.append(", ");
                    }
                    sb.append(DAY_SHORT[d]);
                    first = false;
                }
            }
        }
        sb.setSpan(new StyleSpan(Typeface.BOLD), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private void editLabel(final Alarm a) {
        final EditText input = new EditText(this);
        input.setText(a.label);
        input.setSelectAllOnFocus(true);
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Label")
                .setView(input)
                .setPositiveButton("OK", (d, w) -> {
                    String text = input.getText().toString().trim();
                    a.label = text.isEmpty() ? "Alarm" : text;
                    AlarmStore.update(this, a);
                    AlarmScheduler.apply(this, a);
                    renderAlarms();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addAlarm() {
        java.util.Calendar now = java.util.Calendar.getInstance();
        showTimePicker(now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), (picker, hour, minute) -> {
            Alarm a = new Alarm(AlarmStore.nextId(this), hour, minute, true, 0, "Alarm");
            expandedAlarmId = a.id;
            List<Alarm> all = AlarmStore.load(this);
            all.add(a);
            Collections.sort(all, (x, y) -> (x.hour * 60 + x.minute) - (y.hour * 60 + y.minute));
            AlarmStore.save(this, all);
            long t = AlarmScheduler.apply(this, a);
            renderAlarms();
            if (t > 0) {
                Toast.makeText(this, "Alarm set for " + describeUntil(t - System.currentTimeMillis()),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Time picker with a fixed platform theme, so it cannot clash with the app theme. */
    private void showTimePicker(int hour, int minute, TimePickerDialog.OnTimeSetListener listener) {
        try {
            new TimePickerDialog(this, android.R.style.Theme_Material_Light_Dialog_Alert,
                    listener, hour, minute, is24h()).show();
        } catch (RuntimeException e) {
            Toast.makeText(this, "Unable to open the time picker", Toast.LENGTH_SHORT).show();
        }
    }

    private static String describeUntil(long ms) {
        long minutes = Math.max(0, ms / 60000);
        long days = minutes / (24 * 60);
        long hours = (minutes / 60) % 24;
        long mins = minutes % 60;
        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days).append(days == 1 ? " day " : " days ");
        }
        if (hours > 0) {
            sb.append(hours).append(hours == 1 ? " hour " : " hours ");
        }
        sb.append(mins).append(mins == 1 ? " minute" : " minutes");
        return sb.append(" from now").toString();
    }

    // ------------------------------------------------------------------
    // Clock tab
    // ------------------------------------------------------------------
    private void updateClockPage() {
        boolean h24 = is24h();
        Date now = new Date();
        String time = new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.getDefault()).format(now);
        String ampm = h24 ? "" : new SimpleDateFormat("a", Locale.getDefault()).format(now)
                .toLowerCase(Locale.getDefault());
        String date = new SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(now);
        String all = time + ampm + date;
        if (all.equals(lastClockText)) {
            return;
        }
        lastClockText = all;
        clockTime.setText(time);
        clockAmPm.setText(ampm);
        clockDate.setText(date);
    }

    private void showWorldClocks() {
        final String[][] zones = {
                {"India (Kolkata)", "Asia/Kolkata"}, {"Dubai", "Asia/Dubai"},
                {"London", "Europe/London"}, {"New York", "America/New_York"},
                {"Singapore", "Asia/Singapore"}, {"Tokyo", "Asia/Tokyo"},
                {"Sydney", "Australia/Sydney"}};
        String[] lines = new String[zones.length];
        for (int i = 0; i < zones.length; i++) {
            SimpleDateFormat f = new SimpleDateFormat(is24h() ? "HH:mm, EEE" : "h:mm a, EEE", Locale.getDefault());
            f.setTimeZone(TimeZone.getTimeZone(zones[i][1]));
            lines[i] = zones[i][0] + "  -  " + f.format(new Date());
        }
        new AlertDialog.Builder(this)
                .setTitle("World clock")
                .setItems(lines, null)
                .setPositiveButton("Close", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Timer tab
    // ------------------------------------------------------------------
    private void setupTimerKeypad() {
        GridLayout keypad = findViewById(R.id.timer_keypad);
        for (int i = 0; i < keypad.getChildCount(); i++) {
            View child = keypad.getChildAt(i);
            if (child instanceof TextView) {
                final String digit = ((TextView) child).getText().toString();
                if (!digit.isEmpty()) {
                    child.setOnClickListener(v -> {
                        if (timerDigits.length() >= 6 || (timerDigits.isEmpty() && digit.equals("0"))) {
                            return;
                        }
                        timerDigits += digit;
                        refreshTimerPage();
                        updateFab();
                    });
                }
            }
        }
        findViewById(R.id.timer_backspace).setOnClickListener(v -> {
            if (!timerDigits.isEmpty()) {
                timerDigits = timerDigits.substring(0, timerDigits.length() - 1);
                refreshTimerPage();
                updateFab();
            }
        });
        findViewById(R.id.timer_backspace).setOnLongClickListener(v -> {
            timerDigits = "";
            refreshTimerPage();
            updateFab();
            return true;
        });
    }

    private int[] timerParts() {
        String p = String.format(Locale.US, "%6s", timerDigits).replace(' ', '0');
        return new int[]{Integer.parseInt(p.substring(0, 2)), Integer.parseInt(p.substring(2, 4)),
                Integer.parseInt(p.substring(4, 6))};
    }

    private long timerTotalMs() {
        int[] t = timerParts();
        return (t[0] * 3600L + t[1] * 60L + t[2]) * 1000L;
    }

    private void refreshTimerPage() {
        int st = TimerState.state(this);
        lastTimerState = st;
        timerInput.setVisibility(st == TimerState.IDLE ? View.VISIBLE : View.GONE);
        timerRunning.setVisibility(st == TimerState.IDLE ? View.GONE : View.VISIBLE);
        if (st == TimerState.IDLE) {
            int[] t = timerParts();
            SpannableStringBuilder sb = new SpannableStringBuilder();
            appendUnit(sb, String.valueOf(t[0]), "h");
            appendUnit(sb, String.format(Locale.US, "%02d", t[1]), "m");
            appendUnit(sb, String.format(Locale.US, "%02d", t[2]), "s");
            timerDisplay.setText(sb);
        } else {
            timerRemaining.setText(formatRemaining(TimerState.remainingMs(this)));
        }
    }

    private static void appendUnit(SpannableStringBuilder sb, String number, String unit) {
        sb.append(number);
        int s = sb.length();
        sb.append(unit).append(' ');
        sb.setSpan(new RelativeSizeSpan(0.4f), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private static String formatRemaining(long ms) {
        long total = (ms + 999) / 1000;
        long h = total / 3600;
        long m = (total / 60) % 60;
        long s = total % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, s)
                : String.format(Locale.US, "%02d:%02d", m, s);
    }

    private void onTimerFab() {
        int st = TimerState.state(this);
        if (st == TimerState.IDLE) {
            long total = timerTotalMs();
            if (total <= 0) {
                return;
            }
            TimerState.start(this, total);
        } else if (st == TimerState.RUNNING) {
            TimerState.pause(this);
        } else {
            TimerState.resume(this);
        }
        refreshTimerPage();
        updateFab();
    }

    // ------------------------------------------------------------------
    // Stopwatch tab
    // ------------------------------------------------------------------
    private long stopwatchElapsed() {
        return swAccumulated + (swRunning ? SystemClock.elapsedRealtime() - swStartElapsed : 0);
    }

    private static CharSequence stopwatchText(long ms) {
        long minutes = ms / 60000;
        long seconds = (ms / 1000) % 60;
        long hundredths = (ms / 10) % 100;
        SpannableStringBuilder sb = new SpannableStringBuilder(
                String.format(Locale.US, "%d:%02d", minutes, seconds));
        int s = sb.length();
        sb.append(String.format(Locale.US, ".%02d", hundredths));
        sb.setSpan(new RelativeSizeSpan(0.4f), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private void toggleStopwatch() {
        long now = SystemClock.elapsedRealtime();
        if (swRunning) {
            swAccumulated += now - swStartElapsed;
            swRunning = false;
        } else {
            swStartElapsed = now;
            swRunning = true;
        }
        updateStopwatchButtons();
        updateFab();
    }

    private void lapStopwatch() {
        if (swRunning) {
            swLaps.add(stopwatchElapsed());
            renderLaps();
        }
    }

    private void resetStopwatch() {
        if (!swRunning) {
            swAccumulated = 0;
            swLaps.clear();
            renderLaps();
            updateStopwatchButtons();
            swDisplay.setText(stopwatchText(0));
        }
    }

    private void updateStopwatchButtons() {
        swLap.setVisibility(swRunning ? View.VISIBLE : View.INVISIBLE);
        swReset.setVisibility(!swRunning && swAccumulated > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private void renderLaps() {
        updateStopwatchButtons();
        swLapList.removeAllViews();
        for (int i = swLaps.size() - 1; i >= 0; i--) {
            long total = swLaps.get(i);
            long previous = i == 0 ? 0 : swLaps.get(i - 1);
            TextView row = new TextView(this);
            row.setTextColor(Color.WHITE);
            row.setTextSize(15);
            row.setPadding(0, (int) KioskUtils.dp(this, 8), 0, (int) KioskUtils.dp(this, 8));
            row.setText(String.format(Locale.US, "Lap %d     %s     %s", i + 1,
                    lapFormat(total - previous), lapFormat(total)));
            swLapList.addView(row, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    private static String lapFormat(long ms) {
        return String.format(Locale.US, "%d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms / 10) % 100);
    }
}
