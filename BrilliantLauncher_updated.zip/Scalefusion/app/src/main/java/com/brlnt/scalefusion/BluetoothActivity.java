package com.brlnt.scalefusion;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.Set;

/**
 * Simple Bluetooth manager screen: shows whether Bluetooth is on and the paired devices.
 * Turning Bluetooth on/off and pairing is done in the system Bluetooth settings.
 */
public class BluetoothActivity extends AppCompatActivity {

    private SwitchCompat btSwitch;
    private LinearLayout pairedList;
    private TextView pairedEmpty;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> refresh());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        KioskUtils.hideSystemStatusBar(this);
        KioskUtils.applyRootInsets(findViewById(R.id.bt_root));

        btSwitch = findViewById(R.id.bt_switch);
        pairedList = findViewById(R.id.paired_list);
        pairedEmpty = findViewById(R.id.paired_empty);

        findViewById(R.id.bt_back).setOnClickListener(v -> finish());
        findViewById(R.id.bt_refresh).setOnClickListener(v -> refresh());
        findViewById(R.id.bt_more).setOnClickListener(v -> {
            android.widget.PopupMenu menu = new android.widget.PopupMenu(this, v);
            menu.getMenu().add(0, 1, 0, "Bluetooth settings");
            menu.setOnMenuItemClickListener(item -> {
                openBluetoothSettings();
                return true;
            });
            menu.show();
        });

        // Apps cannot switch Bluetooth on/off themselves on new Android versions,
        // so the switch opens the system Bluetooth settings and then shows the real state.
        btSwitch.setOnClickListener(v -> {
            openBluetoothSettings();
            refresh();
        });

        if (!hasConnectPermission()) {
            KioskApp.allowLeave = true; // the permission box is a system screen
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        KioskUtils.hideSystemStatusBar(this);
        refresh();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
        KioskUtils.onWindowFocus(this, hasFocus);
    }

    private BluetoothAdapter getAdapter() {
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        return manager == null ? null : manager.getAdapter();
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void refresh() {
        pairedList.removeAllViews();
        BluetoothAdapter adapter = getAdapter();

        if (adapter == null) {
            btSwitch.setChecked(false);
            btSwitch.setEnabled(false);
            showEmpty("Bluetooth is not available on this device");
            return;
        }

        btSwitch.setChecked(adapter.isEnabled());

        if (!hasConnectPermission()) {
            showEmpty("Allow \"Nearby devices\" permission to see paired devices");
            return;
        }

        Set<BluetoothDevice> bonded;
        try {
            bonded = adapter.getBondedDevices();
        } catch (SecurityException e) {
            showEmpty("Allow \"Nearby devices\" permission to see paired devices");
            return;
        }

        if (bonded == null || bonded.isEmpty()) {
            showEmpty("No paired devices");
            return;
        }

        pairedEmpty.setVisibility(View.GONE);
        for (BluetoothDevice device : bonded) {
            View row = getLayoutInflater().inflate(R.layout.item_paired_device, pairedList, false);
            String name = device.getName();
            if (name == null || name.isEmpty()) {
                name = device.getAddress();
            }
            ((TextView) row.findViewById(R.id.device_name)).setText(name);
            row.findViewById(R.id.device_settings).setOnClickListener(v -> openBluetoothSettings());
            pairedList.addView(row);
        }
    }

    private void showEmpty(String message) {
        pairedEmpty.setText(message);
        pairedEmpty.setVisibility(View.VISIBLE);
    }

    private void openBluetoothSettings() {
        KioskApp.allowLeave = true; // Settings is a system screen, not a Recents escape
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception e) {
            KioskApp.allowLeave = false;
            Toast.makeText(this, "Unable to open Bluetooth Settings", Toast.LENGTH_SHORT).show();
        }
    }
}
