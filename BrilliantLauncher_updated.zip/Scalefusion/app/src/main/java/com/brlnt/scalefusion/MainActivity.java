package com.brlnt.scalefusion;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PACKAGE_ELEARNING = "com.brilliantpala.lms";
    private static final String PACKAGE_CLASSES = "com.brilliantpala.elearn";
    private static final String PACKAGE_ELIBRARY = "com.brilliantpala.elibrary";
    private static final String ELIBRARY_PLAY_URL =
            "https://play.google.com/store/apps/details?id=" + PACKAGE_ELIBRARY;

    // Used for Exit and for the hidden admin access. Change it here.
    private static final String EXIT_PASSCODE = "123456";

    // Hidden admin access: tap the toolbar title this many times (each tap within the gap)
    private static final int SECRET_TAP_COUNT = 6;
    private static final long SECRET_TAP_GAP_MS = 2000;

    private static final String PREFS = "launcher_prefs";
    private static final String KEY_FONT_SCALE = "font_scale";
    private static final String KEY_ADMIN_MESSAGE = "admin_message";

    /** The home screen that is currently on screen (used by the status-bar blocker overlay). */
    static MainActivity foreground;
    private static boolean overlayPromptShown = false;
    private static boolean quietPromptShown = false;

    private AlertDialog exitDialog;
    private AlertDialog adminDialog;
    private CountDownTimer exitTimer;

    private View quickPanel;
    private View panelScroll;
    private View panelScrim;
    private View panelHandle;
    private SeekBar panelBrightness;
    private boolean panelOpen = false;
    private int panelWidth = 0;
    private float closeStartY = -1;
    private float topSwipeStartY = -1;
    private float edgeSwipeStartX = -1;

    private int titleTaps = 0;
    private long lastTitleTapTime = 0;

    private final BroadcastReceiver timeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updatePanelTime();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        KioskUtils.hideSystemStatusBar(this);
        setContentView(R.layout.activity_main);

        View mainUiContainer = findViewById(R.id.main_ui_container);
        quickPanel = findViewById(R.id.quick_panel_root);
        panelScroll = findViewById(R.id.panel_scroll);
        panelScrim = findViewById(R.id.panel_scrim);
        panelHandle = findViewById(R.id.panel_handle);

        // Edge-to-edge window insets handling (system status bar is hidden, we draw our own)
        ViewCompat.setOnApplyWindowInsetsListener(mainUiContainer, (v, windowInsets) -> {
            Insets i = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            // The control center drops down from the top-middle, just below our own status bar
            quickPanel.setPadding(i.left, i.top + (int) dp(24), i.right, i.bottom);
            // The pull handle sits on the right edge, just above the navigation bar
            FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) panelHandle.getLayoutParams();
            hp.bottomMargin = i.bottom + (int) dp(16);
            hp.rightMargin = i.right;
            panelHandle.setLayoutParams(hp);
            return WindowInsetsCompat.CONSUMED;
        });

        // This is the home screen: Back never leaves it (it only closes the quick panel).
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (panelOpen) {
                    hideQuickPanel();
                }
            }
        });

        setupToolbar();
        setupShortcuts();
        setupQuickPanel();
        applyHomeMetrics();
        applyFontScale();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        ContextCompat.registerReceiver(this, timeReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED);
        updatePanelTime();
    }

    @Override
    protected void onStop() {
        try {
            unregisterReceiver(timeReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = this;
        KioskUtils.hideSystemStatusBar(this);
        // Icons of installed apps can change (install / uninstall / update) while we are away.
        refreshInstalledAppIcons();
        if (ensureOverlayPermission()) {
            ensureQuietPermission();
        }
        KioskUtils.enterQuietMode(this);
        // Device-owner tablets: switch off the notification bar, quick settings and Recents
        KioskUtils.applyDeviceOwnerLockdown(this);
    }

    @Override
    protected void onPause() {
        if (foreground == this) {
            foreground = null;
        }
        if (panelOpen) {
            // Leave the control center closed when coming back
            panelOpen = false;
            quickPanel.animate().cancel();
            panelScroll.animate().cancel();
            panelScrim.animate().cancel();
            resetPanelTransform();
            quickPanel.setVisibility(View.GONE);
        }
        topSwipeStartY = -1;
        edgeSwipeStartX = -1;
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
        // Closes the Android notification shade if it opens by itself (not when the admin opened it)
        KioskUtils.onWindowFocus(this, hasFocus);
    }

    @Override
    protected void onDestroy() {
        // Avoid leaked dialogs / running timer when the screen is recreated (e.g. rotation)
        if (exitDialog != null && exitDialog.isShowing()) {
            exitDialog.dismiss();
        }
        if (adminDialog != null && adminDialog.isShowing()) {
            adminDialog.dismiss();
        }
        if (exitTimer != null) {
            exitTimer.cancel();
        }
        exitDialog = null;
        adminDialog = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // "Display over other apps" permission: lets us block the system notification bar
    // ------------------------------------------------------------------
    private boolean ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            KioskUtils.showBlocker(this);
            return true;
        }
        if (overlayPromptShown) {
            return false;
        }
        overlayPromptShown = true;
        new AlertDialog.Builder(this)
                .setTitle("Allow display over other apps")
                .setMessage("This is needed to block the Android notification bar so only the "
                        + "launcher's own bar is available.")
                .setPositiveButton("Allow", (d, w) -> {
                    try {
                        go(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Later", null)
                .show();
        return false;
    }

    // ------------------------------------------------------------------
    // "Do Not Disturb access": lets the launcher keep notifications from popping up or making sound
    // ------------------------------------------------------------------
    private void ensureQuietPermission() {
        if (KioskUtils.hasQuietAccess(this) || quietPromptShown) {
            return;
        }
        quietPromptShown = true;
        new AlertDialog.Builder(this)
                .setTitle("Turn off notifications")
                .setMessage("Allow \"Do Not Disturb access\" for this app so no notification pops up "
                        + "or makes a sound while the launcher is in use. Alarms still ring.")
                .setPositiveButton("Allow", (d, w) -> {
                    try {
                        go(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                    } catch (RuntimeException e) {
                        Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Control center: swipe it to the right to close it (or tap outside / press Back)
    // ------------------------------------------------------------------
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (panelOpen) {
            // Swipe the control center up to close it
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    closeStartY = ev.getY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (closeStartY >= 0 && closeStartY - ev.getY() > dp(80)) {
                        closeStartY = -1;
                        hideQuickPanel();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    closeStartY = -1;
                    break;
                default:
                    break;
            }
        } else {
            // Swipe down from the very top, or swipe left from the right edge: open the control center
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    topSwipeStartY = ev.getRawY() <= dp(48) ? ev.getRawY() : -1;
                    edgeSwipeStartX = ev.getRawX() >= getResources().getDisplayMetrics().widthPixels - dp(24)
                            ? ev.getRawX() : -1;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (topSwipeStartY >= 0 && ev.getRawY() - topSwipeStartY > dp(40)) {
                        topSwipeStartY = -1;
                        showQuickPanel();
                    } else if (edgeSwipeStartX >= 0 && edgeSwipeStartX - ev.getRawX() > dp(48)) {
                        edgeSwipeStartX = -1;
                        showQuickPanel();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    topSwipeStartY = -1;
                    edgeSwipeStartX = -1;
                    break;
                default:
                    break;
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /** Opens a screen outside the launcher and tells the Recents guard that this is intentional. */
    private void go(Intent intent) {
        KioskApp.allowLeave = true;
        try {
            startActivity(intent);
        } catch (RuntimeException e) {
            KioskApp.allowLeave = false;
            throw e;
        }
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void setupToolbar() {
        // Two-line title: name on top, smaller code line underneath
        TextView title = findViewById(R.id.toolbar_title);
        String full = getString(R.string.toolbar_text);
        SpannableString styled = new SpannableString(full);
        int nl = full.indexOf('\n');
        if (nl > 0) {
            styled.setSpan(new RelativeSizeSpan(0.78f), nl + 1, full.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        title.setText(styled);

        ImageView menuButton = findViewById(R.id.menu_button);
        menuButton.setOnClickListener(this::showPopupMenu);

        // Hidden admin access: tap the title SECRET_TAP_COUNT times, then enter the passcode.
        findViewById(R.id.toolbar_title).setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTitleTapTime > SECRET_TAP_GAP_MS) {
                titleTaps = 0;
            }
            lastTitleTapTime = now;
            titleTaps++;
            if (titleTaps >= SECRET_TAP_COUNT) {
                titleTaps = 0;
                showPasscodeDialog("Admin access", "Enter passcode", false, this::showAdminOptions);
            }
        });
    }

    // ------------------------------------------------------------------
    // Three-dots menu
    // ------------------------------------------------------------------
    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(MainActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_wifi) {
                openSettingsScreen(Settings.ACTION_WIFI_SETTINGS);
            } else if (id == R.id.menu_admin_messages) {
                showAdminMessages();
            } else if (id == R.id.menu_refresh) {
                refreshAll();
            } else if (id == R.id.menu_brightness) {
                showBrightnessDialog();
            } else if (id == R.id.menu_font_size) {
                showFontSizeDialog();
            } else if (id == R.id.menu_device_info) {
                showDeviceInfo();
            } else if (id == R.id.menu_exit) {
                showPasscodeDialog("Enter Passcode", "Are you sure you want to exit?", true,
                        this::exitLauncher);
            } else {
                return false;
            }
            return true;
        });
        popup.show();
    }

    private void showAdminMessages() {
        String message = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_ADMIN_MESSAGE, "No new messages from the admin.");
        new AlertDialog.Builder(this)
                .setTitle("Admin Messages")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void refreshAll() {
        refreshInstalledAppIcons();
        refreshTileStates();
        updatePanelTime();
        applyFontScale();
        panelBrightness.setProgress(currentBrightness());
        Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show();
    }

    private void showBrightnessDialog() {
        SeekBar bar = new SeekBar(this);
        bar.setMax(255);
        bar.setProgress(currentBrightness());
        bar.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    applyBrightness(progress);
                    panelBrightness.setProgress(progress);
                }
            }
        });
        FrameLayout box = new FrameLayout(this);
        int pad = (int) dp(24);
        box.setPadding(pad, pad, pad, pad / 2);
        box.addView(bar);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Brightness")
                .setView(box)
                .setPositiveButton("OK", null);
        if (!Settings.System.canWrite(this)) {
            b.setNeutralButton("Allow system-wide", (d, w) -> {
                try {
                    go(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (RuntimeException e) {
                    Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
                }
            });
        }
        b.show();
    }

    private void showFontSizeDialog() {
        final String[] names = {"Small", "Normal", "Large", "Extra large"};
        final float[] scales = {0.85f, 1f, 1.2f, 1.4f};
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        float current = prefs.getFloat(KEY_FONT_SCALE, 1f);
        int checked = 1;
        for (int i = 0; i < scales.length; i++) {
            if (Math.abs(scales[i] - current) < 0.01f) {
                checked = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("Font Size")
                .setSingleChoiceItems(names, checked, (d, which) -> {
                    prefs.edit().putFloat(KEY_FONT_SCALE, scales[which]).apply();
                    applyFontScale();
                    d.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Scales the toolbar title and app names on the home screen. */
    private void applyFontScale() {
        float s = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat(KEY_FONT_SCALE, 1f);
        ((TextView) findViewById(R.id.toolbar_title)).setTextSize(TypedValue.COMPLEX_UNIT_SP, 16 * s);
        GridLayout grid = findViewById(R.id.app_grid);
        for (int i = 0; i < grid.getChildCount(); i++) {
            View tile = grid.getChildAt(i);
            if (tile instanceof LinearLayout && ((LinearLayout) tile).getChildCount() > 1) {
                View label = ((LinearLayout) tile).getChildAt(1);
                if (label instanceof TextView) {
                    ((TextView) label).setTextSize(TypedValue.COMPLEX_UNIT_SP, 10 * s);
                }
            }
        }
    }

    /**
     * Sizes the app icons and spacing in proportion to the screen width, so the home screen
     * keeps the same look on every tablet: small icons, four per row, labels underneath.
     */
    private void applyHomeMetrics() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float base = Math.min(dm.widthPixels, dm.heightPixels);
        int icon = Math.round(Math.max(dp(40), Math.min(dp(72), base * 0.074f)));
        int gap = Math.round(dp(5));
        int labelHeight = Math.round(dp(14));
        int rowPitch = Math.round(base * 0.155f);
        int bottomPad = Math.max(Math.round(dp(14)), rowPitch - icon - gap - labelHeight);
        int side = Math.round(base * 0.04f);

        GridLayout grid = findViewById(R.id.app_grid);
        grid.setPadding(side, Math.round(dp(30)), side, 0);
        for (int i = 0; i < grid.getChildCount(); i++) {
            View tile = grid.getChildAt(i);
            if (!(tile instanceof LinearLayout) || ((LinearLayout) tile).getChildCount() < 2) {
                continue;
            }
            LinearLayout box = (LinearLayout) tile;
            box.setPadding(Math.round(dp(4)), 0, Math.round(dp(4)), bottomPad);
            View img = box.getChildAt(0);
            ViewGroup.LayoutParams ilp = img.getLayoutParams();
            ilp.width = icon;
            ilp.height = icon;
            img.setLayoutParams(ilp);
            View label = box.getChildAt(1);
            LinearLayout.LayoutParams llp = (LinearLayout.LayoutParams) label.getLayoutParams();
            llp.topMargin = gap;
            label.setLayoutParams(llp);
        }
    }

    @SuppressLint("HardwareIds")
    private void showDeviceInfo() {
        String appVersion = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersion = pi.versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
            // leave blank
        }
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String text = "Manufacturer: " + Build.MANUFACTURER
                + "\nModel: " + Build.MODEL
                + "\nAndroid version: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nSecurity patch: " + Build.VERSION.SECURITY_PATCH
                + "\nDevice ID: " + deviceId
                + "\nApp version: " + appVersion;
        new AlertDialog.Builder(this)
                .setTitle("Device Information")
                .setMessage(text)
                .setPositiveButton("OK", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Passcode dialog (used for Exit and for admin access)
    // ------------------------------------------------------------------
    private void showPasscodeDialog(String title, String subtitle, boolean showTimer, Runnable onSuccess) {
        // Ignore repeated taps while a dialog is already open
        if (exitDialog != null && exitDialog.isShowing()) {
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        exitDialog = dialog;

        // Transparent window so our custom rounded background shows
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        ((TextView) dialogView.findViewById(R.id.tv_dialog_title)).setText(title);
        ((TextView) dialogView.findViewById(R.id.tv_dialog_subtitle)).setText(subtitle);

        TextView tvTimer = dialogView.findViewById(R.id.tv_timer);
        EditText etPasscode = dialogView.findViewById(R.id.et_passcode);
        TextView btnCancel = dialogView.findViewById(R.id.btn_cancel);
        TextView btnOk = dialogView.findViewById(R.id.btn_ok);

        if (exitTimer != null) {
            exitTimer.cancel();
            exitTimer = null;
        }
        if (showTimer) {
            // 30 second countdown shown in the dialog
            exitTimer = new CountDownTimer(30000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    tvTimer.setText(String.valueOf(millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    tvTimer.setText("0");
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            };
            exitTimer.start();
        } else {
            tvTimer.setVisibility(View.GONE);
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnOk.setOnClickListener(v -> {
            String input = etPasscode.getText().toString().trim();
            if (input.equals(EXIT_PASSCODE)) {
                dialog.dismiss();
                onSuccess.run();
            } else {
                etPasscode.setText("");
                Toast.makeText(MainActivity.this, "Incorrect passcode", Toast.LENGTH_SHORT).show();
            }
        });

        // Always stop the timer when the dialog goes away (cancel, OK, or tap outside)
        dialog.setOnDismissListener(d -> {
            if (exitTimer != null) {
                exitTimer.cancel();
            }
        });

        dialog.show();
    }

    private void exitLauncher() {
        // Give the normal Android notification bar back, then close our task.
        KioskUtils.hideBlocker(this);
        KioskUtils.releaseDeviceOwnerLockdown(this);
        KioskUtils.leaveQuietMode(this);
        finishAffinity();
    }

    // ------------------------------------------------------------------
    // Hidden admin options (6 taps on the title + passcode)
    // ------------------------------------------------------------------
    private void showAdminOptions() {
        String[] items = {"Open Settings", "Control Panel", "App List", "Notification"};
        adminDialog = new AlertDialog.Builder(this)
                .setTitle("Admin access")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        openSettingsScreen(Settings.ACTION_SETTINGS);
                    } else if (which == 1) {
                        showControlPanel();
                    } else if (which == 2) {
                        showAppList();
                    } else {
                        openNotificationShade();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        adminDialog.show();
    }

    /** Admin only (passcode): opens the Android notification shade; blocking returns when it is closed. */
    private void openNotificationShade() {
        if (!KioskUtils.openShadeForAdmin(this)) {
            Toast.makeText(this, "Could not open the notification bar on this device",
                    Toast.LENGTH_LONG).show();
        }
    }

    /** Shortcuts to the main Android control panels. */
    private void showControlPanel() {
        final String[] names = {"Settings home", "Wi-Fi", "Bluetooth", "Display", "Sound", "Apps",
                "Date & time", "Storage", "Battery", "Accessibility", "Security",
                "Language & input", "About device"};
        final String[] actions = {Settings.ACTION_SETTINGS, Settings.ACTION_WIFI_SETTINGS,
                Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_DISPLAY_SETTINGS,
                Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS,
                Settings.ACTION_DATE_SETTINGS, Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
                Intent.ACTION_POWER_USAGE_SUMMARY, Settings.ACTION_ACCESSIBILITY_SETTINGS,
                Settings.ACTION_SECURITY_SETTINGS, Settings.ACTION_INPUT_METHOD_SETTINGS,
                Settings.ACTION_DEVICE_INFO_SETTINGS};
        new AlertDialog.Builder(this)
                .setTitle("Control Panel")
                .setItems(names, (d, which) -> openSettingsScreen(actions[which]))
                .setNegativeButton("Close", null)
                .show();
    }

    /** Lists every app installed on the device; tap one to open it. */
    private void showAppList() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));

        ArrayAdapter<ResolveInfo> adapter =
                new ArrayAdapter<ResolveInfo>(this, R.layout.item_app, R.id.app_label, apps) {
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View row = super.getView(position, convertView, parent);
                        ResolveInfo info = getItem(position);
                        if (info != null) {
                            ((TextView) row.findViewById(R.id.app_label)).setText(info.loadLabel(pm));
                            ((ImageView) row.findViewById(R.id.app_icon)).setImageDrawable(info.loadIcon(pm));
                        }
                        return row;
                    }
                };

        new AlertDialog.Builder(this)
                .setTitle("App list")
                .setAdapter(adapter, (d, which) -> launchApp(apps.get(which).activityInfo.packageName))
                .setNegativeButton("Close", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Control center (pulled out with the arrow on the right edge).
    // It is display only: the tiles and the slider do nothing when touched.
    // ------------------------------------------------------------------
    @SuppressLint("ClickableViewAccessibility")
    private void setupQuickPanel() {
        panelScrim.setOnClickListener(v -> hideQuickPanel());

        // Panel is about 70% of the screen width, anchored to the right edge
        int screenW = getResources().getDisplayMetrics().widthPixels;
        panelWidth = (int) Math.min(screenW, Math.min(dp(640), Math.max(dp(340), screenW * 0.7f)));
        ViewGroup.LayoutParams lp = panelScroll.getLayoutParams();
        lp.width = panelWidth;
        panelScroll.setLayoutParams(lp);

        // Brightness bar is just for looks: it shows the level but cannot be moved
        panelBrightness = findViewById(R.id.panel_brightness);
        panelBrightness.setProgress(currentBrightness());
        panelBrightness.setOnTouchListener((v, e) -> true);
        panelBrightness.setFocusable(false);

        // The arrow: drag it to the left (or tap it) to bring the control center out
        panelHandle.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private boolean opened;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        opened = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!opened && downX - e.getRawX() > dp(36)) {
                            opened = true;
                            showQuickPanel();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!opened && Math.abs(e.getRawX() - downX) < dp(10)) {
                            v.performClick();
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        panelHandle.setOnClickListener(v -> showQuickPanel());
    }

    private void resetPanelTransform() {
        panelScroll.setTranslationY(0f);
        panelScroll.setAlpha(1f);
        panelScrim.setAlpha(1f);
    }

    /** How far the panel must move up to be fully off screen. */
    private float panelHiddenOffset() {
        return -(panelScroll.getHeight() + dp(48));
    }

    void showQuickPanel() {
        if (panelOpen) {
            return;
        }
        panelOpen = true;
        updatePanelTime();
        refreshTileStates();
        panelBrightness.setProgress(currentBrightness());

        quickPanel.animate().cancel();
        panelScroll.animate().cancel();
        panelScrim.animate().cancel();
        quickPanel.setAlpha(1f);
        quickPanel.setVisibility(View.VISIBLE);
        panelScroll.setAlpha(0f); // hidden until it has been measured
        panelScrim.setAlpha(0f);
        panelScroll.post(() -> {
            if (!panelOpen) {
                return;
            }
            panelScroll.setTranslationY(panelHiddenOffset());
            panelScroll.setAlpha(1f);
            panelScroll.animate().translationY(0f).setDuration(240).start();
        });
        panelScrim.animate().alpha(1f).setDuration(240).start();
    }

    private void hideQuickPanel() {
        if (!panelOpen) {
            return;
        }
        panelOpen = false;
        panelScrim.animate().cancel();
        panelScroll.animate().cancel();
        panelScrim.animate().alpha(0f).setDuration(180).start();
        panelScroll.animate().translationY(panelHiddenOffset()).setDuration(180)
                .withEndAction(() -> {
                    if (!panelOpen) {
                        quickPanel.setVisibility(View.GONE);
                        resetPanelTransform();
                    }
                }).start();
    }

    private void updatePanelTime() {
        ((TextView) findViewById(R.id.panel_time)).setText(KioskUtils.clockText(this));
        ((TextView) findViewById(R.id.panel_date)).setText(KioskUtils.dateText());
    }

    /** Dims the icon of every tile that is switched off (read only - the tiles do not respond to touch). */
    private void refreshTileStates() {
        findViewById(R.id.icon_flash).setAlpha(0.45f);
        findViewById(R.id.icon_hotspot).setAlpha(0.45f);

        boolean rotationOn = Settings.System.getInt(getContentResolver(),
                Settings.System.ACCELEROMETER_ROTATION, 0) == 1;
        findViewById(R.id.icon_rotation).setAlpha(rotationOn ? 1f : 0.45f);

        boolean wifiOn = false;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiOn = wm != null && wm.isWifiEnabled();
        } catch (SecurityException ignored) {
            // treat as off
        }
        findViewById(R.id.icon_wifi).setAlpha(wifiOn ? 1f : 0.45f);

        boolean flight = Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        findViewById(R.id.icon_flight).setAlpha(flight ? 1f : 0.45f);
    }

    private int currentBrightness() {
        try {
            return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {
            return 128;
        }
    }

    private void applyBrightness(int value) {
        int level = Math.max(value, 10);
        if (Settings.System.canWrite(this)) {
            // System-wide brightness (needs "Modify system settings" allowed for this app)
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, level);
            } catch (Exception ignored) {
                // nothing else to do
            }
        } else {
            // Without that permission only this screen's brightness can change
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = level / 255f;
            getWindow().setAttributes(lp);
        }
    }

    private void openSettingsScreen(String action) {
        try {
            go(new Intent(action));
        } catch (RuntimeException e) {
            Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // App shortcuts
    // ------------------------------------------------------------------
    private void setupShortcuts() {
        // 1. Brilliant Pala e-learning
        findViewById(R.id.btn_elearning).setOnClickListener(v -> launchApp(PACKAGE_ELEARNING));

        // 2. Brilliant Pala Classes
        findViewById(R.id.btn_classes).setOnClickListener(v -> launchApp(PACKAGE_CLASSES));

        // 3. Bluetooth Manager screen (inside this app)
        findViewById(R.id.btn_bluetooth).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, BluetoothActivity.class)));

        // 4. Time (alarm, clock, timer, stopwatch - inside this app)
        findViewById(R.id.btn_clock).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, TimeActivity.class)));

        // 5. Brilliant Pala e-library: opens the app, or its Play Store page if not installed
        findViewById(R.id.btn_elibrary).setOnClickListener(v -> openElibrary());

        refreshInstalledAppIcons();
    }

    /** Shows the real icon of the e-library app when it is installed. */
    private void refreshInstalledAppIcons() {
        PackageManager pm = getPackageManager();
        ImageView img = findViewById(R.id.img_elibrary);
        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            try {
                img.setImageDrawable(pm.getApplicationIcon(PACKAGE_ELIBRARY));
            } catch (PackageManager.NameNotFoundException e) {
                img.setImageResource(R.drawable.icon_elibrary);
            }
        } else {
            img.setImageResource(R.drawable.icon_elibrary);
        }
    }

    private void openElibrary() {
        PackageManager pm = getPackageManager();
        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            launchApp(PACKAGE_ELIBRARY);
            return;
        }
        try {
            // Opens the Play Store app directly on the e-library page
            go(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + PACKAGE_ELIBRARY)));
        } catch (ActivityNotFoundException e) {
            try {
                // No Play Store app: fall back to the web link
                go(new Intent(Intent.ACTION_VIEW, Uri.parse(ELIBRARY_PLAY_URL)));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "Play Store not available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void launchApp(String packageName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) {
            Toast.makeText(this, "Application not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            go(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Unable to open application", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPackageInstalled(PackageManager pm, String packageName) {
        try {
            pm.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** SeekBar listener with the two unused callbacks already implemented. */
    private abstract static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }
}
