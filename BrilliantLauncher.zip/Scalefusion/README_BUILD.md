# Brilliant Launcher (v1.2) - how to build the APK

## Option A: Android Studio (easiest)
1. Unzip, then in Android Studio choose **File > Open** and select the `Scalefusion` folder.
2. Wait for "Gradle sync" to finish (needs internet the first time, JDK 17 or newer - the one bundled with Android Studio is fine).
3. **Build > Generate App Bundles or APKs > Generate APKs** (or **Build > Generate Signed App Bundle / APK > APK**
   and pick `app/release.jks`, alias `brilliant`, passwords are in `app/build.gradle.kts`).
4. Click "locate" in the pop-up. The file is `app/build/outputs/apk/release/app-release.apk`.

## Option B: command line
    cd Scalefusion
    ./gradlew assembleRelease          (Windows: gradlew.bat assembleRelease)
APK: `app/build/outputs/apk/release/app-release.apk`

## Install on the tablet
    adb install -r app-release.apk
(or copy the APK to the tablet and open it). It is signed with the same key as before, so it updates the old version.

## First run on the tablet
* Tap **Allow** on "Display over other apps" - this is what blocks the Android notification bar.
* Brightness slider / rotation tile: Settings > Apps > Brilliant Launcher > Modify system settings > Allow.
* Allow Notifications (Android 13+) so alarms/timers can show.

## Optional: totally switch off the real notification bar
The overlay is best-effort. For a guaranteed block make the app "device owner" (tablet must have no Google/other accounts,
or be freshly reset), then run once:
    adb shell dpm set-device-owner com.brlnt.scalefusion/.KioskAdminReceiver
The launcher then disables the system status bar automatically (and gives it back when you Exit).

## Where to change things
* Passcode: `EXIT_PASSCODE` in `MainActivity.java` (currently 123456)
* Icons: `res/drawable/icon_time.png`, `icon_bluetooth.png`, `icon_classes.png`
* Backgrounds: `res/drawable/bg_image.jpg` (portrait), `res/drawable-land/bg_image.jpg` (landscape)
* Status bar: `CustomStatusBar.java`; notification panel: `res/layout/layout_quick_panel.xml`
* Time app: `TimeActivity.java` + `res/layout/*time*.xml`; blue colour = `time_blue` in `res/values/colors.xml`
