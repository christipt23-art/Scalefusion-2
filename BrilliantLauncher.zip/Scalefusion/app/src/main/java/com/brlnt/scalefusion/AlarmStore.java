package com.brlnt.scalefusion;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Saves the alarm list in SharedPreferences. */
final class AlarmStore {
    private static final String PREFS = "time_alarms";
    private static final String KEY_LIST = "alarms";
    private static final String KEY_NEXT_ID = "next_id";

    private AlarmStore() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized List<Alarm> load(Context c) {
        SharedPreferences p = prefs(c);
        List<Alarm> list = new ArrayList<>();
        String json = p.getString(KEY_LIST, null);
        if (json == null) {
            // First run: the two example alarms (switched off)
            list.add(new Alarm(nextId(c), 8, 30, false, 0b0111110, "Alarm"));  // Mon-Fri
            list.add(new Alarm(nextId(c), 9, 0, false, 0b1000001, "Alarm"));   // Sat, Sun
            save(c, list);
            return list;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(Alarm.fromJson(arr.getJSONObject(i)));
            }
        } catch (JSONException ignored) {
            // corrupted: start empty
        }
        return list;
    }

    static synchronized void save(Context c, List<Alarm> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Alarm a : list) {
                arr.put(a.toJson());
            }
        } catch (JSONException ignored) {
            return;
        }
        prefs(c).edit().putString(KEY_LIST, arr.toString()).apply();
    }

    static synchronized int nextId(Context c) {
        SharedPreferences p = prefs(c);
        int id = p.getInt(KEY_NEXT_ID, 1);
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply();
        return id;
    }

    static Alarm find(Context c, int id) {
        for (Alarm a : load(c)) {
            if (a.id == id) {
                return a;
            }
        }
        return null;
    }

    static synchronized void update(Context c, Alarm updated) {
        List<Alarm> list = load(c);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == updated.id) {
                list.set(i, updated);
            }
        }
        save(c, list);
    }
}
