package com.brlnt.scalefusion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

/**
 * The launcher's own status bar: time on the left, Wi-Fi and battery % on the right.
 * Used instead of the Android system status bar (which is hidden and blocked).
 */
public class CustomStatusBar extends LinearLayout {

    private final TextView timeView;
    private final ImageView wifiView;
    private final TextView batteryView;
    private final BatteryIconView batteryIcon;

    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handle(intent);
        }
    };

    public CustomStatusBar(Context context) {
        this(context, null);
    }

    public CustomStatusBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setBackgroundColor(ContextCompat.getColor(context, R.color.status_bar_bg));
        int pad = (int) KioskUtils.dp(context, 12);
        setPadding(pad, 0, pad, 0);

        timeView = new TextView(context);
        timeView.setTextColor(Color.WHITE);
        timeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        timeView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        timeView.setIncludeFontPadding(false);
        addView(timeView, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        int iconSize = (int) KioskUtils.dp(context, 14);
        wifiView = new ImageView(context);
        wifiView.setImageResource(R.drawable.ic_wifi_status);
        wifiView.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        LayoutParams wlp = new LayoutParams(iconSize, iconSize);
        wlp.setMarginEnd((int) KioskUtils.dp(context, 8));
        addView(wifiView, wlp);

        batteryIcon = new BatteryIconView(context);
        batteryIcon.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        LayoutParams blp = new LayoutParams((int) KioskUtils.dp(context, 9), (int) KioskUtils.dp(context, 16));
        blp.setMarginEnd((int) KioskUtils.dp(context, 4));
        addView(batteryIcon, blp);

        batteryView = new TextView(context);
        batteryView.setTextColor(Color.WHITE);
        batteryView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        batteryView.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        batteryView.setIncludeFontPadding(false);
        addView(batteryView, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        timeView.setText(KioskUtils.clockText(context));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        Intent sticky = ContextCompat.registerReceiver(getContext(), receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);

        // Live network changes (the old CONNECTIVITY_CHANGE broadcast is no longer delivered)
        try {
            connectivityManager = (ConnectivityManager) getContext().getApplicationContext()
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager != null) {
                networkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        post(CustomStatusBar.this::updateWifi);
                    }

                    @Override
                    public void onLost(Network network) {
                        post(CustomStatusBar.this::updateWifi);
                    }

                    @Override
                    public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                        post(CustomStatusBar.this::updateWifi);
                    }
                };
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            }
        } catch (RuntimeException e) {
            networkCallback = null;
        }

        timeView.setText(KioskUtils.clockText(getContext()));
        updateWifi();
        if (sticky != null) {
            updateBattery(sticky);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        try {
            getContext().unregisterReceiver(receiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        if (connectivityManager != null && networkCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback);
            } catch (RuntimeException ignored) {
                // already unregistered
            }
        }
        networkCallback = null;
        super.onDetachedFromWindow();
    }

    private void handle(Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            return;
        }
        if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
            updateBattery(intent);
        } else if (Intent.ACTION_TIME_TICK.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            timeView.setText(KioskUtils.clockText(getContext()));
        } else {
            updateWifi();
        }
    }

    private void updateBattery(Intent intent) {
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scale > 0) {
            int percent = level * 100 / scale;
            batteryView.setText(percent + "%");
            batteryIcon.setLevel(percent);
        }
    }

    private void updateWifi() {
        Context app = getContext().getApplicationContext();
        boolean enabled = false;
        boolean connected = false;
        try {
            WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
            enabled = wm != null && wm.isWifiEnabled();
            ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities caps = n == null ? null : cm.getNetworkCapabilities(n);
            connected = caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (SecurityException ignored) {
            // permission missing: show as off
        }
        wifiView.setAlpha(connected ? 1f : (enabled ? 0.6f : 0.3f));
    }
}
