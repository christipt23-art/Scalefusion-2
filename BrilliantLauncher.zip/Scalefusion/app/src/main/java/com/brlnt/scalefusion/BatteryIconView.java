package com.brlnt.scalefusion;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Small upright battery icon for the status bar, filled from the bottom up to the charge level. */
public class BatteryIconView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF body = new RectF();
    private final RectF nub = new RectF();
    private final RectF fill = new RectF();
    private int level = 100;

    public BatteryIconView(Context context) {
        this(context, null);
    }

    public BatteryIconView(Context context, AttributeSet attrs) {
        super(context, attrs);
        trackPaint.setColor(Color.argb(110, 255, 255, 255));
        fillPaint.setColor(Color.WHITE);
    }

    public void setLevel(int percent) {
        int clamped = Math.max(0, Math.min(100, percent));
        if (clamped != level) {
            level = clamped;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float nubH = h * 0.1f;
        float r = Math.max(1f, w * 0.14f);

        nub.set(w * 0.3f, 0, w * 0.7f, nubH + r);
        canvas.drawRoundRect(nub, r / 2, r / 2, fillPaint);

        body.set(0, nubH, w, h);
        canvas.drawRoundRect(body, r, r, trackPaint);

        float fillTop = body.bottom - body.height() * level / 100f;
        canvas.save();
        canvas.clipRect(0, fillTop, w, h);
        canvas.drawRoundRect(body, r, r, fillPaint);
        canvas.restore();
    }
}
