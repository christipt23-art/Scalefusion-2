package com.brlnt.scalefusion;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Helpers that keep the Android system notification bar out of the way. */
public final class KioskUtils {

    private static View blockerView;
    private static float blockerDownY = -1;

    private KioskUtils() {
    }

    // ------------------------------------------------------------------
    // Hide the system status bar (we draw our own: CustomStatusBar)
    // ------------------------------------------------------------------
    public static void hideSystemStatusBar(Activity activity) {
        Window window = activity.getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        controller.hide(WindowInsetsCompat.Type.statusBars());
    }

    /** Pads the root view so content stays clear of the navigation bar and any camera cut-out. */
    public static void applyRootInsets(View root) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets i = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    // ------------------------------------------------------------------
    // Overlay that swallows swipes on the status bar area (best effort)
    // ------------------------------------------------------------------
    public static void showBlocker(Context context) {
        if (blockerView != null || !Settings.canDrawOverlays(context)) {
            return;
        }
        Context app = context.getApplicationContext();
        try {
            WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            View v = new View(app);
            v.setOnTouchListener((view, ev) -> {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        blockerDownY = ev.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (blockerDownY >= 0 && ev.getRawY() - blockerDownY > dp(app, 40)) {
                            blockerDownY = -1;
                            MainActivity main = MainActivity.foreground;
                            if (main != null) {
                                main.runOnUiThread(main::showQuickPanel);
                            }
                        }
                        break;
                    default:
                        if (ev.getActionMasked() == MotionEvent.ACTION_UP
                                || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                            blockerDownY = -1;
                        }
                        break;
                }
                return true; // consume everything that lands here
            });
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    statusBarHeight(app),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            wm.addView(v, lp);
            blockerView = v;
        } catch (Exception ignored) {
            blockerView = null;
        }
    }

    public static void hideBlocker(Context context) {
        if (blockerView == null) {
            return;
        }
        try {
            WindowManager wm = (WindowManager) context.getApplicationContext()
                    .getSystemService(Context.WINDOW_SERVICE);
            wm.removeView(blockerView);
        } catch (Exception ignored) {
            // already gone
        }
        blockerView = null;
    }

    private static int statusBarHeight(Context c) {
        Resources r = c.getResources();
        int id = r.getIdentifier("status_bar_height", "dimen", "android");
        int h = id > 0 ? r.getDimensionPixelSize(id) : 0;
        return Math.max(h, (int) dp(c, 26));
    }

    // ------------------------------------------------------------------
    // Device owner (optional, full lock-down of the real status bar)
    // ------------------------------------------------------------------
    @SuppressWarnings("deprecation")
    public static void setSystemStatusBarDisabled(Context context, boolean disabled) {
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm != null && dpm.isDeviceOwnerApp(context.getPackageName())) {
                dpm.setStatusBarDisabled(new ComponentName(context, KioskAdminReceiver.class), disabled);
            }
        } catch (Exception ignored) {
            // not device owner / not supported
        }
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------
    public static float dp(Context c, float value) {
        return value * c.getResources().getDisplayMetrics().density;
    }

    /** "1:37 pm" (or 24-hour "13:37" if the device uses 24-hour time). */
    public static String clockText(Context c) {
        boolean h24 = DateFormat.is24HourFormat(c);
        SimpleDateFormat f = new SimpleDateFormat(h24 ? "HH:mm" : "h:mm a", Locale.getDefault());
        return f.format(new Date()).toLowerCase(Locale.getDefault());
    }

    /** "Monday, 12 Oct" */
    public static String dateText() {
        return new SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(new Date());
    }
}
