package com.brlnt.scalefusion;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Helpers that keep the Android notification bar, quick settings and Recents out of reach.
 *
 * Layers, from weakest to strongest:
 *  1. The system status bar is hidden (we draw our own).
 *  2. A transparent overlay swallows every touch on the status-bar strip (needs "Display over other apps").
 *  3. If the shade still opens, it is collapsed again as soon as our window loses focus.
 *  4. Device-owner mode (see README): the status bar, notification shade, quick settings and the
 *     Recents button are switched off by Android itself. This is the only fully guaranteed layer.
 */
public final class KioskUtils {

    /** Apps the launcher may open while locked down (device-owner mode). */
    private static final String[] LOCK_TASK_EXTRA_PACKAGES = {
            "com.brilliantpala.lms",
            "com.brilliantpala.elearn",
            "com.brilliantpala.elibrary",
            "com.android.settings",
            "com.android.vending",
            "com.google.android.packageinstaller",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.bluetooth"
    };

    private static View blockerView;

    /** True while the admin has deliberately opened the Android notification shade. */
    private static boolean shadeAllowed = false;
    private static boolean shadeFocusLost = false;

    private static final String QUIET_PREFS = "kiosk_quiet";
    private static final String KEY_PREV_FILTER = "prev_filter";

    private KioskUtils() {
    }

    // ------------------------------------------------------------------
    // Hide the system status bar (we draw our own: CustomStatusBar)
    // ------------------------------------------------------------------
    public static void hideSystemStatusBar(Activity activity) {
        Window window = activity.getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        controller.hide(WindowInsetsCompat.Type.statusBars());
    }

    /** Pads the root view so content stays clear of the navigation bar and any camera cut-out. */
    public static void applyRootInsets(View root) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets i = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    // ------------------------------------------------------------------
    // Overlay that swallows every touch on the status-bar strip
    // ------------------------------------------------------------------
    public static void showBlocker(Context context) {
        if (blockerView != null || !Settings.canDrawOverlays(context)) {
            return;
        }
        Context app = context.getApplicationContext();
        try {
            WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            View v = new View(app);
            // Consume everything that lands here: a swipe down does nothing.
            v.setOnTouchListener((view, ev) -> true);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    statusBarHeight(app) + (int) dp(app, 10),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            wm.addView(v, lp);
            blockerView = v;
        } catch (RuntimeException ignored) {
            blockerView = null;
        }
    }

    public static void hideBlocker(Context context) {
        if (blockerView == null) {
            return;
        }
        try {
            WindowManager wm = (WindowManager) context.getApplicationContext()
                    .getSystemService(Context.WINDOW_SERVICE);
            wm.removeView(blockerView);
        } catch (RuntimeException ignored) {
            // already gone
        }
        blockerView = null;
    }

    private static int statusBarHeight(Context c) {
        Resources r = c.getResources();
        int id = r.getIdentifier("status_bar_height", "dimen", "android");
        int h = id > 0 ? r.getDimensionPixelSize(id) : 0;
        return Math.max(h, (int) dp(c, 26));
    }

    // ------------------------------------------------------------------
    // Close the notification shade / quick settings if it manages to open
    // ------------------------------------------------------------------
    @SuppressWarnings({"WrongConstant", "JavaReflectionMemberAccess", "PrivateApi"})
    public static void collapseSystemPanels(Context context) {
        if (shadeAllowed) {
            return; // the admin opened it on purpose
        }
        try {
            Object service = context.getSystemService("statusbar");
            if (service != null) {
                service.getClass().getMethod("collapsePanels").invoke(service);
            }
        } catch (Exception ignored) {
            // not available on this Android version: the other layers still apply
        }
    }

    /** Called from every activity's onWindowFocusChanged. */
    public static void onWindowFocus(Activity activity, boolean hasFocus) {
        if (shadeAllowed) {
            if (!hasFocus) {
                shadeFocusLost = true;
            } else if (shadeFocusLost) {
                endAdminShade(activity); // the shade was closed: block everything again
            }
            return;
        }
        if (!hasFocus) {
            collapseSystemPanels(activity);
        }
    }

    // ------------------------------------------------------------------
    // Admin only: open the Android notification shade (after the passcode)
    // ------------------------------------------------------------------
    @SuppressWarnings({"WrongConstant", "JavaReflectionMemberAccess", "PrivateApi", "deprecation"})
    public static boolean openShadeForAdmin(Activity activity) {
        shadeAllowed = true;
        shadeFocusLost = false;
        hideBlocker(activity);
        if (isDeviceOwner(activity)) {
            try {
                DevicePolicyManager dpm =
                        (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = new ComponentName(activity, KioskAdminReceiver.class);
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_HOME
                        | DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS);
                dpm.setStatusBarDisabled(admin, false);
            } catch (RuntimeException ignored) {
                // keep going: the shade may still open
            }
        }
        boolean opened = false;
        try {
            Object service = activity.getSystemService("statusbar");
            if (service != null) {
                service.getClass().getMethod("expandNotificationsPanel").invoke(service);
                opened = true;
            }
        } catch (Exception ignored) {
            opened = false;
        }
        if (!opened) {
            endAdminShade(activity);
            return false;
        }
        // Safety net: if the shade never took focus, switch the blocking back on anyway
        final Activity a = activity;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (shadeAllowed && !shadeFocusLost) {
                endAdminShade(a);
            }
        }, 4000);
        return true;
    }

    private static void endAdminShade(Activity activity) {
        shadeAllowed = false;
        shadeFocusLost = false;
        showBlocker(activity);
        applyDeviceOwnerLockdown(activity);
        collapseSystemPanels(activity);
    }

    // ------------------------------------------------------------------
    // Quiet mode: no notification pops up, makes a sound or lights the screen
    // (Do Not Disturb, "alarms only"; needs Do Not Disturb access for the app)
    // ------------------------------------------------------------------
    public static boolean hasQuietAccess(Context context) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    @SuppressWarnings("deprecation")
    public static void enterQuietMode(Context context) {
        try {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm == null || !nm.isNotificationPolicyAccessGranted()) {
                return;
            }
            SharedPreferences p = context.getSharedPreferences(QUIET_PREFS, Context.MODE_PRIVATE);
            if (!p.contains(KEY_PREV_FILTER)) {
                p.edit().putInt(KEY_PREV_FILTER, nm.getCurrentInterruptionFilter()).apply();
            }
            // Nothing may break through except alarms; hide every visual notification effect too
            nm.setNotificationPolicy(new NotificationManager.Policy(0,
                    NotificationManager.Policy.PRIORITY_SENDERS_ANY,
                    NotificationManager.Policy.PRIORITY_SENDERS_ANY,
                    NotificationManager.Policy.SUPPRESSED_EFFECT_LIGHTS
                            | NotificationManager.Policy.SUPPRESSED_EFFECT_PEEK
                            | NotificationManager.Policy.SUPPRESSED_EFFECT_STATUS_BAR
                            | NotificationManager.Policy.SUPPRESSED_EFFECT_BADGE
                            | NotificationManager.Policy.SUPPRESSED_EFFECT_AMBIENT));
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
        } catch (RuntimeException ignored) {
            // policy refused: nothing more we can do
        }
    }

    public static void leaveQuietMode(Context context) {
        try {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            SharedPreferences p = context.getSharedPreferences(QUIET_PREFS, Context.MODE_PRIVATE);
            if (nm != null && nm.isNotificationPolicyAccessGranted() && p.contains(KEY_PREV_FILTER)) {
                int prev = p.getInt(KEY_PREV_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL);
                nm.setInterruptionFilter(prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
                        ? NotificationManager.INTERRUPTION_FILTER_ALL : prev);
            }
            p.edit().remove(KEY_PREV_FILTER).apply();
        } catch (RuntimeException ignored) {
            // nothing to undo
        }
    }

    // ------------------------------------------------------------------
    // Device owner: full lock-down (status bar, shade, quick settings and Recents)
    // ------------------------------------------------------------------
    public static boolean isDeviceOwner(Context context) {
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isDeviceOwnerApp(context.getPackageName());
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Turns the lock-down on. Does nothing unless the app is the device owner. */
    @SuppressWarnings("deprecation")
    public static void applyDeviceOwnerLockdown(Activity activity) {
        if (!isDeviceOwner(activity)) {
            return;
        }
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(activity, KioskAdminReceiver.class);

            String[] packages = new String[LOCK_TASK_EXTRA_PACKAGES.length + 1];
            packages[0] = activity.getPackageName();
            System.arraycopy(LOCK_TASK_EXTRA_PACKAGES, 0, packages, 1, LOCK_TASK_EXTRA_PACKAGES.length);
            dpm.setLockTaskPackages(admin, packages);

            // Only the Home button stays: no Recents (square), no notifications, no quick settings.
            dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_HOME);
            dpm.setStatusBarDisabled(admin, true);

            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null && am.getLockTaskModeState() == ActivityManager.LOCK_TASK_MODE_NONE) {
                activity.startLockTask();
            }
        } catch (RuntimeException ignored) {
            // device policy refused: the other layers still apply
        }
    }

    /** Gives the system bars and Recents back (used by Exit). */
    @SuppressWarnings("deprecation")
    public static void releaseDeviceOwnerLockdown(Activity activity) {
        if (!isDeviceOwner(activity)) {
            return;
        }
        try {
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null && am.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE) {
                activity.stopLockTask();
            }
        } catch (RuntimeException ignored) {
            // not in lock-task mode
        }
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.setStatusBarDisabled(new ComponentName(activity, KioskAdminReceiver.class), false);
        } catch (RuntimeException ignored) {
            // nothing to undo
        }
    }

    /** Status bar block for non-activity callers (e.g. after boot). */
    @SuppressWarnings("deprecation")
    public static void disableStatusBarIfOwner(Context context) {
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm != null && dpm.isDeviceOwnerApp(context.getPackageName())) {
                dpm.setStatusBarDisabled(new ComponentName(context, KioskAdminReceiver.class), true);
            }
        } catch (RuntimeException ignored) {
            // not device owner / not supported
        }
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------
    public static float dp(Context c, float value) {
        return value * c.getResources().getDisplayMetrics().density;
    }

    /** "1:37 pm" (or 24-hour "13:37" if the device uses 24-hour time). */
    public static String clockText(Context c) {
        boolean h24 = DateFormat.is24HourFormat(c);
        SimpleDateFormat f = new SimpleDateFormat(h24 ? "HH:mm" : "h:mm a", Locale.getDefault());
        return f.format(new Date()).toLowerCase(Locale.getDefault());
    }

    /** "Monday, 12 Oct" */
    public static String dateText() {
        return new SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(new Date());
    }
}
