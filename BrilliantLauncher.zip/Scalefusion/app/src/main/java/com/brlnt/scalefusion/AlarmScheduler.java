package com.brlnt.scalefusion;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;
import java.util.List;

/** Sets / cancels the system alarms for the Time app. */
final class AlarmScheduler {
    static final String EXTRA_KIND = "kind";
    static final String EXTRA_ID = "alarm_id";
    static final String EXTRA_LABEL = "label";

    static final int KIND_ALARM = 0;
    static final int KIND_TIMER = 1;
    static final int KIND_SNOOZE = 2;

    private static final int TIMER_REQUEST = 900001;
    private static final int SNOOZE_REQUEST = 900002;

    private AlarmScheduler() {
    }

    private static PendingIntent firePending(Context c, int request, int kind, int id, String label) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra(EXTRA_KIND, kind);
        i.putExtra(EXTRA_ID, id);
        i.putExtra(EXTRA_LABEL, label);
        return PendingIntent.getBroadcast(c, request, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void setClock(Context c, long triggerAt, PendingIntent fire) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, TimeActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(triggerAt, show), fire);
    }

    private static void cancelPending(Context c, PendingIntent pi) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(pi);
        }
    }

    // ---------------- alarms ----------------
    /** Next time this alarm should ring, or -1 if never. */
    static long nextTrigger(Alarm a) {
        Calendar now = Calendar.getInstance();
        for (int i = 0; i < 8; i++) {
            Calendar t = (Calendar) now.clone();
            t.add(Calendar.DAY_OF_YEAR, i);
            t.set(Calendar.HOUR_OF_DAY, a.hour);
            t.set(Calendar.MINUTE, a.minute);
            t.set(Calendar.SECOND, 0);
            t.set(Calendar.MILLISECOND, 0);
            if (t.getTimeInMillis() > now.getTimeInMillis()) {
                int dow = t.get(Calendar.DAY_OF_WEEK) - 1; // 0 = Sunday
                if (a.days == 0 || ((a.days >> dow) & 1) == 1) {
                    return t.getTimeInMillis();
                }
            }
        }
        return -1;
    }

    /** Schedules the alarm if it is on, cancels it if it is off. Returns the trigger time or -1. */
    static long apply(Context c, Alarm a) {
        if (!a.enabled) {
            cancel(c, a);
            return -1;
        }
        return schedule(c, a);
    }

    static long schedule(Context c, Alarm a) {
        long t = nextTrigger(a);
        if (t > 0) {
            setClock(c, t, firePending(c, a.id, KIND_ALARM, a.id, a.label));
        }
        return t;
    }

    static void cancel(Context c, Alarm a) {
        cancelPending(c, firePending(c, a.id, KIND_ALARM, a.id, a.label));
    }

    static void rescheduleAll(Context c) {
        List<Alarm> list = AlarmStore.load(c);
        for (Alarm a : list) {
            if (a.enabled) {
                schedule(c, a);
            }
        }
    }

    // ---------------- timer ----------------
    static void scheduleTimer(Context c, long endAtMs) {
        setClock(c, endAtMs, firePending(c, TIMER_REQUEST, KIND_TIMER, -2, "Timer"));
    }

    static void cancelTimer(Context c) {
        cancelPending(c, firePending(c, TIMER_REQUEST, KIND_TIMER, -2, "Timer"));
    }

    // ---------------- snooze ----------------
    static void scheduleSnooze(Context c, String label, long delayMs) {
        setClock(c, System.currentTimeMillis() + delayMs,
                firePending(c, SNOOZE_REQUEST, KIND_SNOOZE, -3, label));
    }
}
