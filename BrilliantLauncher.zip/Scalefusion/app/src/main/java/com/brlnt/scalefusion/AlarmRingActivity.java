package com.brlnt.scalefusion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/** Full screen shown while an alarm or timer is ringing. */
public class AlarmRingActivity extends AppCompatActivity {

    private final BroadcastReceiver finishReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        KioskUtils.hideSystemStatusBar(this);
        setContentView(R.layout.activity_alarm_ring);
        KioskUtils.applyRootInsets(findViewById(R.id.ring_root));

        int kind = getIntent().getIntExtra(AlarmScheduler.EXTRA_KIND, AlarmScheduler.KIND_ALARM);
        String label = getIntent().getStringExtra(AlarmScheduler.EXTRA_LABEL);

        ((TextView) findViewById(R.id.ring_time)).setText(KioskUtils.clockText(this));
        ((TextView) findViewById(R.id.ring_label)).setText(label == null ? "Alarm" : label);

        View snooze = findViewById(R.id.ring_snooze);
        if (kind == AlarmScheduler.KIND_TIMER) {
            snooze.setVisibility(View.GONE);
        }
        snooze.setOnClickListener(v -> send(AlarmService.ACTION_SNOOZE));
        findViewById(R.id.ring_dismiss).setOnClickListener(v -> send(AlarmService.ACTION_STOP));

        ContextCompat.registerReceiver(this, finishReceiver,
                new IntentFilter(AlarmService.ACTION_FINISH_RING), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    private void send(String action) {
        startService(new Intent(this, AlarmService.class).setAction(action));
        finish();
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(finishReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        super.onDestroy();
    }
}
