package com.brlnt.scalefusion;

import android.app.admin.DeviceAdminReceiver;

/**
 * Only needed if you make this app the "device owner" (see README). It lets the launcher
 * switch the real system status bar / notification shade completely off.
 */
public class KioskAdminReceiver extends DeviceAdminReceiver {
}
