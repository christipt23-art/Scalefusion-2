package com.brlnt.scalefusion;

import android.app.Activity;
import android.app.Application;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * Application class. Its one job: keep the "Recents" (square button) screen from being used.
 *
 * - On a device-owner tablet the system itself hides Recents (lock-task mode, see KioskUtils).
 * - On every other tablet the Recents button cannot be removed by an app, so this class does the
 *   next best thing: if none of the launcher's screens is in front shortly after one was paused
 *   (which is what opening Recents looks like) and we did not send the user away on purpose,
 *   the launcher is brought straight back and Recents closes.
 */
public class KioskApp extends Application {

    /** True while the user is deliberately somewhere else (another app, a Settings page, a permission box). */
    static volatile boolean allowLeave = false;

    private static final long CHECK_DELAY_MS = 900;

    private int resumed = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable guard = this::bringHomeIfLeft;

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityResumed(Activity activity) {
                resumed++;
                allowLeave = false;
                handler.removeCallbacks(guard);
            }

            @Override
            public void onActivityPaused(Activity activity) {
                resumed = Math.max(0, resumed - 1);
                if (activity instanceof AlarmRingActivity) {
                    // After an alarm is dismissed, give the user back whatever they were doing
                    allowLeave = true;
                }
                handler.removeCallbacks(guard);
                handler.postDelayed(guard, CHECK_DELAY_MS);
            }

            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            }

            @Override
            public void onActivityStarted(Activity activity) {
            }

            @Override
            public void onActivityStopped(Activity activity) {
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
            }

            @Override
            public void onActivityDestroyed(Activity activity) {
            }
        });
    }

    private void bringHomeIfLeft() {
        if (resumed > 0 || allowLeave) {
            return;
        }
        if (KioskUtils.isDeviceOwner(this)) {
            return; // lock-task mode already blocks Recents
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (pm == null || !pm.isInteractive() || (km != null && km.isKeyguardLocked())) {
            return; // screen is off or locked: nothing to do
        }
        if (!Settings.canDrawOverlays(this)) {
            return; // without this permission Android will not let us start a screen from the background
        }
        try {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP
                            | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
        } catch (RuntimeException ignored) {
            // blocked by the system: nothing more we can do
        }
    }
}
