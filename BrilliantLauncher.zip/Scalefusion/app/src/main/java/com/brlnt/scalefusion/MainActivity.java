package com.brlnt.scalefusion;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PACKAGE_ELEARNING = "com.brilliantpala.lms";
    private static final String PACKAGE_CLASSES = "com.brilliantpala.elearn";
    private static final String PACKAGE_ELIBRARY = "com.brilliantpala.elibrary";
    private static final String ELIBRARY_PLAY_URL =
            "https://play.google.com/store/apps/details?id=" + PACKAGE_ELIBRARY;

    // Used for Exit and for the hidden admin access. Change it here.
    private static final String EXIT_PASSCODE = "123456";

    // Hidden admin access: tap the toolbar title this many times (each tap within the gap)
    private static final int SECRET_TAP_COUNT = 6;
    private static final long SECRET_TAP_GAP_MS = 2000;

    private static final String PREFS = "launcher_prefs";
    private static final String KEY_FONT_SCALE = "font_scale";
    private static final String KEY_ADMIN_MESSAGE = "admin_message";

    /** The home screen that is currently on screen (used by the status-bar blocker overlay). */
    static MainActivity foreground;
    private static boolean overlayPromptShown = false;

    private AlertDialog exitDialog;
    private AlertDialog adminDialog;
    private CountDownTimer exitTimer;

    private View quickPanel;
    private SeekBar panelBrightness;
    private float swipeStartY = -1;
    private float closeStartY = -1;
    private boolean torchOn = false;

    private int titleTaps = 0;
    private long lastTitleTapTime = 0;

    private final BroadcastReceiver timeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updatePanelTime();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        KioskUtils.hideSystemStatusBar(this);
        setContentView(R.layout.activity_main);

        View mainUiContainer = findViewById(R.id.main_ui_container);
        quickPanel = findViewById(R.id.quick_panel_root);

        // Edge-to-edge window insets handling (system status bar is hidden, we draw our own)
        ViewCompat.setOnApplyWindowInsetsListener(mainUiContainer, (v, windowInsets) -> {
            Insets i = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            // The quick panel slides down from just below our own status bar
            quickPanel.setPadding(i.left, i.top + (int) dp(26), i.right, i.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        // This is the home screen: Back never leaves it (it only closes the quick panel).
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (quickPanel.getVisibility() == View.VISIBLE) {
                    hideQuickPanel();
                }
            }
        });

        setupToolbar();
        setupShortcuts();
        setupQuickPanel();
        applyFontScale();
        KioskUtils.setSystemStatusBarDisabled(this, true);
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        ContextCompat.registerReceiver(this, timeReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED);
        updatePanelTime();
    }

    @Override
    protected void onStop() {
        try {
            unregisterReceiver(timeReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = this;
        KioskUtils.hideSystemStatusBar(this);
        // Icons of installed apps can change (install / uninstall / update) while we are away.
        refreshInstalledAppIcons();
        ensureOverlayPermission();
    }

    @Override
    protected void onPause() {
        if (foreground == this) {
            foreground = null;
        }
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            KioskUtils.hideSystemStatusBar(this);
        }
    }

    @Override
    protected void onDestroy() {
        // Avoid leaked dialogs / running timer when the screen is recreated (e.g. rotation)
        if (exitDialog != null && exitDialog.isShowing()) {
            exitDialog.dismiss();
        }
        if (adminDialog != null && adminDialog.isShowing()) {
            adminDialog.dismiss();
        }
        if (exitTimer != null) {
            exitTimer.cancel();
        }
        exitDialog = null;
        adminDialog = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // "Display over other apps" permission: lets us block the system notification bar
    // ------------------------------------------------------------------
    private void ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            KioskUtils.showBlocker(this);
            return;
        }
        if (overlayPromptShown) {
            return;
        }
        overlayPromptShown = true;
        new AlertDialog.Builder(this)
                .setTitle("Allow display over other apps")
                .setMessage("This is needed to block the Android notification bar so only the "
                        + "launcher's own bar is available.")
                .setPositiveButton("Allow", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Swipe down from the top bar to open the quick panel, swipe up to close it
    // ------------------------------------------------------------------
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        boolean panelVisible = quickPanel != null && quickPanel.getVisibility() == View.VISIBLE;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                swipeStartY = (!panelVisible && ev.getY() < dp(120)) ? ev.getY() : -1;
                closeStartY = panelVisible ? ev.getY() : -1;
                break;
            case MotionEvent.ACTION_MOVE:
                if (swipeStartY >= 0 && ev.getY() - swipeStartY > dp(48)) {
                    swipeStartY = -1;
                    showQuickPanel();
                }
                if (closeStartY >= 0 && closeStartY - ev.getY() > dp(60)) {
                    closeStartY = -1;
                    hideQuickPanel();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                swipeStartY = -1;
                closeStartY = -1;
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void setupToolbar() {
        ImageView menuButton = findViewById(R.id.menu_button);
        menuButton.setOnClickListener(this::showPopupMenu);

        // Hidden admin access: tap the title SECRET_TAP_COUNT times, then enter the passcode.
        findViewById(R.id.toolbar_title).setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTitleTapTime > SECRET_TAP_GAP_MS) {
                titleTaps = 0;
            }
            lastTitleTapTime = now;
            titleTaps++;
            if (titleTaps >= SECRET_TAP_COUNT) {
                titleTaps = 0;
                showPasscodeDialog("Admin access", "Enter passcode", false, this::showAdminOptions);
            }
        });
    }

    // ------------------------------------------------------------------
    // Three-dots menu
    // ------------------------------------------------------------------
    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(MainActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_wifi) {
                openSettingsScreen(Settings.ACTION_WIFI_SETTINGS);
            } else if (id == R.id.menu_admin_messages) {
                showAdminMessages();
            } else if (id == R.id.menu_refresh) {
                refreshAll();
            } else if (id == R.id.menu_brightness) {
                showBrightnessDialog();
            } else if (id == R.id.menu_font_size) {
                showFontSizeDialog();
            } else if (id == R.id.menu_device_info) {
                showDeviceInfo();
            } else if (id == R.id.menu_exit) {
                showPasscodeDialog("Enter Passcode", "Are you sure you want to exit?", true,
                        this::exitLauncher);
            } else {
                return false;
            }
            return true;
        });
        popup.show();
    }

    private void showAdminMessages() {
        String message = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_ADMIN_MESSAGE, "No new messages from the admin.");
        new AlertDialog.Builder(this)
                .setTitle("Admin Messages")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void refreshAll() {
        refreshInstalledAppIcons();
        refreshTileStates();
        updatePanelTime();
        applyFontScale();
        panelBrightness.setProgress(currentBrightness());
        Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show();
    }

    private void showBrightnessDialog() {
        SeekBar bar = new SeekBar(this);
        bar.setMax(255);
        bar.setProgress(currentBrightness());
        bar.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    applyBrightness(progress);
                    panelBrightness.setProgress(progress);
                }
            }
        });
        FrameLayout box = new FrameLayout(this);
        int pad = (int) dp(24);
        box.setPadding(pad, pad, pad, pad / 2);
        box.addView(bar);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Brightness")
                .setView(box)
                .setPositiveButton("OK", null);
        if (!Settings.System.canWrite(this)) {
            b.setNeutralButton("Allow system-wide", (d, w) -> {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
                }
            });
        }
        b.show();
    }

    private void showFontSizeDialog() {
        final String[] names = {"Small", "Normal", "Large", "Extra large"};
        final float[] scales = {0.85f, 1f, 1.2f, 1.4f};
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        float current = prefs.getFloat(KEY_FONT_SCALE, 1f);
        int checked = 1;
        for (int i = 0; i < scales.length; i++) {
            if (Math.abs(scales[i] - current) < 0.01f) {
                checked = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("Font Size")
                .setSingleChoiceItems(names, checked, (d, which) -> {
                    prefs.edit().putFloat(KEY_FONT_SCALE, scales[which]).apply();
                    applyFontScale();
                    d.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Scales the toolbar title and app names on the home screen. */
    private void applyFontScale() {
        float s = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat(KEY_FONT_SCALE, 1f);
        ((TextView) findViewById(R.id.toolbar_title)).setTextSize(TypedValue.COMPLEX_UNIT_SP, 14 * s);
        GridLayout grid = findViewById(R.id.app_grid);
        for (int i = 0; i < grid.getChildCount(); i++) {
            View tile = grid.getChildAt(i);
            if (tile instanceof LinearLayout && ((LinearLayout) tile).getChildCount() > 1) {
                View label = ((LinearLayout) tile).getChildAt(1);
                if (label instanceof TextView) {
                    ((TextView) label).setTextSize(TypedValue.COMPLEX_UNIT_SP, 11 * s);
                }
            }
        }
    }

    @SuppressLint("HardwareIds")
    private void showDeviceInfo() {
        String appVersion = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersion = pi.versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
            // leave blank
        }
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String text = "Manufacturer: " + Build.MANUFACTURER
                + "\nModel: " + Build.MODEL
                + "\nAndroid version: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nSecurity patch: " + Build.VERSION.SECURITY_PATCH
                + "\nDevice ID: " + deviceId
                + "\nApp version: " + appVersion;
        new AlertDialog.Builder(this)
                .setTitle("Device Information")
                .setMessage(text)
                .setPositiveButton("OK", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Passcode dialog (used for Exit and for admin access)
    // ------------------------------------------------------------------
    private void showPasscodeDialog(String title, String subtitle, boolean showTimer, Runnable onSuccess) {
        // Ignore repeated taps while a dialog is already open
        if (exitDialog != null && exitDialog.isShowing()) {
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        exitDialog = dialog;

        // Transparent window so our custom rounded background shows
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        ((TextView) dialogView.findViewById(R.id.tv_dialog_title)).setText(title);
        ((TextView) dialogView.findViewById(R.id.tv_dialog_subtitle)).setText(subtitle);

        TextView tvTimer = dialogView.findViewById(R.id.tv_timer);
        EditText etPasscode = dialogView.findViewById(R.id.et_passcode);
        TextView btnCancel = dialogView.findViewById(R.id.btn_cancel);
        TextView btnOk = dialogView.findViewById(R.id.btn_ok);

        if (exitTimer != null) {
            exitTimer.cancel();
            exitTimer = null;
        }
        if (showTimer) {
            // 30 second countdown shown in the dialog
            exitTimer = new CountDownTimer(30000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    tvTimer.setText(String.valueOf(millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    tvTimer.setText("0");
                }
            };
            exitTimer.start();
        } else {
            tvTimer.setVisibility(View.GONE);
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnOk.setOnClickListener(v -> {
            String input = etPasscode.getText().toString().trim();
            if (input.equals(EXIT_PASSCODE)) {
                dialog.dismiss();
                onSuccess.run();
            } else {
                etPasscode.setText("");
                Toast.makeText(MainActivity.this, "Incorrect passcode", Toast.LENGTH_SHORT).show();
            }
        });

        // Always stop the timer when the dialog goes away (cancel, OK, or tap outside)
        dialog.setOnDismissListener(d -> {
            if (exitTimer != null) {
                exitTimer.cancel();
            }
        });

        dialog.show();
    }

    private void exitLauncher() {
        // Give the normal Android notification bar back, then close our task.
        KioskUtils.hideBlocker(this);
        KioskUtils.setSystemStatusBarDisabled(this, false);
        finishAffinity();
    }

    // ------------------------------------------------------------------
    // Hidden admin options (6 taps on the title + passcode)
    // ------------------------------------------------------------------
    private void showAdminOptions() {
        String[] items = {"Open Settings", "Control Panel", "App List", "Open system notification bar"};
        adminDialog = new AlertDialog.Builder(this)
                .setTitle("Admin access")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        openSettingsScreen(Settings.ACTION_SETTINGS);
                    } else if (which == 1) {
                        showControlPanel();
                    } else if (which == 2) {
                        showAppList();
                    } else {
                        openSystemNotificationShade();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        adminDialog.show();
    }

    /** Shortcuts to the main Android control panels. */
    private void showControlPanel() {
        final String[] names = {"Settings home", "Wi-Fi", "Bluetooth", "Display", "Sound", "Apps",
                "Date & time", "Storage", "Battery", "Accessibility", "Security",
                "Language & input", "About device"};
        final String[] actions = {Settings.ACTION_SETTINGS, Settings.ACTION_WIFI_SETTINGS,
                Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_DISPLAY_SETTINGS,
                Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS,
                Settings.ACTION_DATE_SETTINGS, Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
                Intent.ACTION_POWER_USAGE_SUMMARY, Settings.ACTION_ACCESSIBILITY_SETTINGS,
                Settings.ACTION_SECURITY_SETTINGS, Settings.ACTION_INPUT_METHOD_SETTINGS,
                Settings.ACTION_DEVICE_INFO_SETTINGS};
        new AlertDialog.Builder(this)
                .setTitle("Control Panel")
                .setItems(names, (d, which) -> openSettingsScreen(actions[which]))
                .setNegativeButton("Close", null)
                .show();
    }

    /** Lists every app installed on the device; tap one to open it. */
    private void showAppList() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));

        ArrayAdapter<ResolveInfo> adapter =
                new ArrayAdapter<ResolveInfo>(this, R.layout.item_app, R.id.app_label, apps) {
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View row = super.getView(position, convertView, parent);
                        ResolveInfo info = getItem(position);
                        if (info != null) {
                            ((TextView) row.findViewById(R.id.app_label)).setText(info.loadLabel(pm));
                            ((ImageView) row.findViewById(R.id.app_icon)).setImageDrawable(info.loadIcon(pm));
                        }
                        return row;
                    }
                };

        new AlertDialog.Builder(this)
                .setTitle("App list")
                .setAdapter(adapter, (d, which) -> launchApp(apps.get(which).activityInfo.packageName))
                .setNegativeButton("Close", null)
                .show();
    }

    /** Opens the normal Android notification shade (may be blocked on some devices / by device policy). */
    @SuppressLint({"WrongConstant", "PrivateApi"})
    private void openSystemNotificationShade() {
        try {
            Object statusBarService = getSystemService("statusbar");
            Class<?> statusBarManager = Class.forName("android.app.StatusBarManager");
            statusBarManager.getMethod("expandNotificationsPanel").invoke(statusBarService);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open the notification bar on this device", Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------
    // Quick panel (notification-style panel inside the launcher)
    // ------------------------------------------------------------------
    private void setupQuickPanel() {
        findViewById(R.id.panel_scrim).setOnClickListener(v -> hideQuickPanel());

        // Panel is about 70% of the screen width, centred
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int width = (int) Math.min(screenW, Math.min(dp(640), Math.max(dp(340), screenW * 0.7f)));
        View scroll = findViewById(R.id.panel_scroll);
        ViewGroup.LayoutParams lp = scroll.getLayoutParams();
        lp.width = width;
        scroll.setLayoutParams(lp);

        panelBrightness = findViewById(R.id.panel_brightness);
        panelBrightness.setProgress(currentBrightness());
        panelBrightness.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    applyBrightness(progress);
                }
            }
        });

        findViewById(R.id.tile_flash).setOnClickListener(v -> toggleFlashlight());
        findViewById(R.id.tile_rotation).setOnClickListener(v -> toggleRotation());
        findViewById(R.id.tile_wifi).setOnClickListener(v -> openWifiPanel());
        findViewById(R.id.tile_hotspot).setOnClickListener(v -> openHotspotSettings());
        findViewById(R.id.tile_flight).setOnClickListener(v ->
                openSettingsScreen(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        findViewById(R.id.panel_bg_apps).setOnClickListener(v ->
                Toast.makeText(this, "Use the Recent apps button on the navigation bar", Toast.LENGTH_SHORT).show());
    }

    void showQuickPanel() {
        if (quickPanel.getVisibility() == View.VISIBLE) {
            return;
        }
        updatePanelTime();
        refreshTileStates();
        panelBrightness.setProgress(currentBrightness());
        quickPanel.setAlpha(0f);
        quickPanel.setVisibility(View.VISIBLE);
        quickPanel.animate().alpha(1f).setDuration(150).start();
    }

    private void hideQuickPanel() {
        quickPanel.animate().alpha(0f).setDuration(150)
                .withEndAction(() -> quickPanel.setVisibility(View.GONE)).start();
    }

    private void updatePanelTime() {
        ((TextView) findViewById(R.id.panel_time)).setText(KioskUtils.clockText(this));
        ((TextView) findViewById(R.id.panel_date)).setText(KioskUtils.dateText());
    }

    /** Dims the icon of every tile that is switched off. */
    private void refreshTileStates() {
        findViewById(R.id.icon_flash).setAlpha(torchOn ? 1f : 0.45f);

        boolean rotationOn = Settings.System.getInt(getContentResolver(),
                Settings.System.ACCELEROMETER_ROTATION, 0) == 1;
        findViewById(R.id.icon_rotation).setAlpha(rotationOn ? 1f : 0.45f);

        boolean wifiOn = false;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiOn = wm != null && wm.isWifiEnabled();
        } catch (SecurityException ignored) {
            // treat as off
        }
        findViewById(R.id.icon_wifi).setAlpha(wifiOn ? 1f : 0.45f);

        boolean flight = Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        findViewById(R.id.icon_flight).setAlpha(flight ? 1f : 0.45f);

        findViewById(R.id.icon_hotspot).setAlpha(0.8f);
    }

    private int currentBrightness() {
        try {
            return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {
            return 128;
        }
    }

    private void applyBrightness(int value) {
        int level = Math.max(value, 10);
        if (Settings.System.canWrite(this)) {
            // System-wide brightness (needs "Modify system settings" allowed for this app)
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, level);
            } catch (Exception ignored) {
                // nothing else to do
            }
        } else {
            // Without that permission only this screen's brightness can change
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = level / 255f;
            getWindow().setAttributes(lp);
        }
    }

    private void toggleRotation() {
        if (Settings.System.canWrite(this)) {
            boolean on = Settings.System.getInt(getContentResolver(),
                    Settings.System.ACCELEROMETER_ROTATION, 0) == 1;
            Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, on ? 0 : 1);
            refreshTileStates();
        } else {
            openSettingsScreen(Settings.ACTION_DISPLAY_SETTINGS);
        }
    }

    private void toggleFlashlight() {
        try {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String torchId = null;
            for (String id : cameraManager.getCameraIdList()) {
                Boolean hasFlash = cameraManager.getCameraCharacteristics(id)
                        .get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (hasFlash != null && hasFlash) {
                    torchId = id;
                    break;
                }
            }
            if (torchId == null) {
                Toast.makeText(this, "No flashlight on this device", Toast.LENGTH_SHORT).show();
                return;
            }
            torchOn = !torchOn;
            cameraManager.setTorchMode(torchId, torchOn);
            refreshTileStates();
        } catch (CameraAccessException | IllegalArgumentException | SecurityException e) {
            torchOn = false;
            refreshTileStates();
            Toast.makeText(this, "Flashlight unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void openWifiPanel() {
        try {
            startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
        } catch (Exception e) {
            openSettingsScreen(Settings.ACTION_WIFI_SETTINGS);
        }
    }

    private void openHotspotSettings() {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.TetherSettings"));
            startActivity(intent);
        } catch (Exception e) {
            openSettingsScreen(Settings.ACTION_WIRELESS_SETTINGS);
        }
    }

    private void openSettingsScreen(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // App shortcuts
    // ------------------------------------------------------------------
    private void setupShortcuts() {
        // 1. Brilliant Pala e-learning
        findViewById(R.id.btn_elearning).setOnClickListener(v -> launchApp(PACKAGE_ELEARNING));

        // 2. Brilliant Pala Classes
        findViewById(R.id.btn_classes).setOnClickListener(v -> launchApp(PACKAGE_CLASSES));

        // 3. Bluetooth Manager screen (inside this app)
        findViewById(R.id.btn_bluetooth).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, BluetoothActivity.class)));

        // 4. Time (alarm, clock, timer, stopwatch - inside this app)
        findViewById(R.id.btn_clock).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, TimeActivity.class)));

        // 5. Brilliant Pala e-library: opens the app, or its Play Store page if not installed
        findViewById(R.id.btn_elibrary).setOnClickListener(v -> openElibrary());

        refreshInstalledAppIcons();
    }

    /** Shows the real icon of the e-library app when it is installed. */
    private void refreshInstalledAppIcons() {
        PackageManager pm = getPackageManager();
        ImageView img = findViewById(R.id.img_elibrary);
        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            try {
                img.setImageDrawable(pm.getApplicationIcon(PACKAGE_ELIBRARY));
            } catch (PackageManager.NameNotFoundException e) {
                img.setImageResource(R.drawable.icon_elibrary);
            }
        } else {
            img.setImageResource(R.drawable.icon_elibrary);
        }
    }

    private void openElibrary() {
        PackageManager pm = getPackageManager();
        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            launchApp(PACKAGE_ELIBRARY);
            return;
        }
        try {
            // Opens the Play Store app directly on the e-library page
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + PACKAGE_ELIBRARY)));
        } catch (ActivityNotFoundException e) {
            try {
                // No Play Store app: fall back to the web link
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ELIBRARY_PLAY_URL)));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "Play Store not available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void launchApp(String packageName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) {
            Toast.makeText(this, "Application not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Unable to open application", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPackageInstalled(PackageManager pm, String packageName) {
        try {
            pm.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** SeekBar listener with the two unused callbacks already implemented. */
    private abstract static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }
}
