package com.brlnt.scalefusion;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String PACKAGE_ELEARNING = "com.brilliantpala.lms";
    private static final String PACKAGE_CLASSES = "com.brilliantpala.elearn";
    private static final String PACKAGE_ELIBRARY = "com.brilliantpala.elibrary";
    private static final String ELIBRARY_PLAY_URL =
            "https://play.google.com/store/apps/details?id=" + PACKAGE_ELIBRARY;

    // We try Google clock first, then AOSP clock standard package
    private static final String PACKAGE_GOOGLE_CLOCK = "com.google.android.deskclock";
    private static final String PACKAGE_AOSP_CLOCK = "com.android.deskclock";

    // Used for Exit and for the hidden admin access. Change it here.
    private static final String EXIT_PASSCODE = "123456";

    // Hidden admin access: tap the toolbar title this many times (each tap within the gap)
    private static final int SECRET_TAP_COUNT = 6;
    private static final long SECRET_TAP_GAP_MS = 2000;

    private AlertDialog exitDialog;
    private AlertDialog adminDialog;
    private CountDownTimer exitTimer;

    private View quickPanel;
    private float swipeStartY = -1;
    private boolean torchOn = false;

    private int titleTaps = 0;
    private long lastTitleTapTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View mainUiContainer = findViewById(R.id.main_ui_container);
        View statusBarBg = findViewById(R.id.status_bar_bg);
        quickPanel = findViewById(R.id.quick_panel_root);

        // Edge-to-edge window insets handling
        ViewCompat.setOnApplyWindowInsetsListener(mainUiContainer, (v, windowInsets) -> {
            Insets systemBars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Grey view fills the status bar area
            android.view.ViewGroup.LayoutParams params = statusBarBg.getLayoutParams();
            params.height = systemBars.top;
            statusBarBg.setLayoutParams(params);

            // Side and bottom padding for the navigation bar
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);

            // The quick panel slides down from just below the status bar
            quickPanel.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);

            return WindowInsetsCompat.CONSUMED;
        });

        // This is the home screen: Back never leaves it (it only closes the quick panel).
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (quickPanel.getVisibility() == View.VISIBLE) {
                    hideQuickPanel();
                }
            }
        });

        setupToolbar();
        setupShortcuts();
        setupQuickPanel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Icons of installed apps can change (install / uninstall / update) while we are away.
        refreshInstalledAppIcons();
    }

    @Override
    protected void onDestroy() {
        // Avoid leaked dialogs / running timer when the screen is recreated (e.g. rotation)
        if (exitDialog != null && exitDialog.isShowing()) {
            exitDialog.dismiss();
        }
        if (adminDialog != null && adminDialog.isShowing()) {
            adminDialog.dismiss();
        }
        if (exitTimer != null) {
            exitTimer.cancel();
        }
        exitDialog = null;
        adminDialog = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // Swipe down from the top bar to open the quick panel
    // ------------------------------------------------------------------
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                boolean panelHidden = quickPanel == null || quickPanel.getVisibility() != View.VISIBLE;
                swipeStartY = (panelHidden && ev.getY() < dp(120)) ? ev.getY() : -1;
                break;
            case MotionEvent.ACTION_MOVE:
                if (swipeStartY >= 0 && ev.getY() - swipeStartY > dp(48)) {
                    swipeStartY = -1;
                    showQuickPanel();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                swipeStartY = -1;
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void setupToolbar() {
        ImageView menuButton = findViewById(R.id.menu_button);
        menuButton.setOnClickListener(this::showPopupMenu);

        // Hidden admin access: tap the title SECRET_TAP_COUNT times, then enter the passcode.
        findViewById(R.id.toolbar_title).setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTitleTapTime > SECRET_TAP_GAP_MS) {
                titleTaps = 0;
            }
            lastTitleTapTime = now;
            titleTaps++;
            if (titleTaps >= SECRET_TAP_COUNT) {
                titleTaps = 0;
                showPasscodeDialog("Admin access", "Enter passcode", false, this::showAdminOptions);
            }
        });
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(MainActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.menu_wifi) {
                openSettingsScreen(Settings.ACTION_WIFI_SETTINGS);
                return true;
            } else if (item.getItemId() == R.id.menu_exit) {
                showPasscodeDialog("Enter Passcode", "Are you sure you want to exit?", true,
                        this::exitLauncher);
                return true;
            }
            return false;
        });
        popup.show();
    }

    // ------------------------------------------------------------------
    // Passcode dialog (used for Exit and for admin access)
    // ------------------------------------------------------------------
    private void showPasscodeDialog(String title, String subtitle, boolean showTimer, Runnable onSuccess) {
        // Ignore repeated taps while a dialog is already open
        if (exitDialog != null && exitDialog.isShowing()) {
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        exitDialog = dialog;

        // Transparent window so our custom rounded background shows
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        ((TextView) dialogView.findViewById(R.id.tv_dialog_title)).setText(title);
        ((TextView) dialogView.findViewById(R.id.tv_dialog_subtitle)).setText(subtitle);

        TextView tvTimer = dialogView.findViewById(R.id.tv_timer);
        EditText etPasscode = dialogView.findViewById(R.id.et_passcode);
        TextView btnCancel = dialogView.findViewById(R.id.btn_cancel);
        TextView btnOk = dialogView.findViewById(R.id.btn_ok);

        if (exitTimer != null) {
            exitTimer.cancel();
            exitTimer = null;
        }
        if (showTimer) {
            // 30 second countdown shown in the dialog
            exitTimer = new CountDownTimer(30000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    tvTimer.setText(String.valueOf(millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    tvTimer.setText("0");
                }
            };
            exitTimer.start();
        } else {
            tvTimer.setVisibility(View.GONE);
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnOk.setOnClickListener(v -> {
            String input = etPasscode.getText().toString().trim();
            if (input.equals(EXIT_PASSCODE)) {
                dialog.dismiss();
                onSuccess.run();
            } else {
                etPasscode.setText("");
                Toast.makeText(MainActivity.this, "Incorrect passcode", Toast.LENGTH_SHORT).show();
            }
        });

        // Always stop the timer when the dialog goes away (cancel, OK, or tap outside)
        dialog.setOnDismissListener(d -> {
            if (exitTimer != null) {
                exitTimer.cancel();
            }
        });

        dialog.show();
    }

    private void exitLauncher() {
        // Home launcher: closes our task; the system shows the default home again.
        finishAffinity();
    }

    private void showAdminOptions() {
        String[] items = {"Open Settings", "Open system notification bar"};
        adminDialog = new AlertDialog.Builder(this)
                .setTitle("Admin access")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        openSettingsScreen(Settings.ACTION_SETTINGS);
                    } else {
                        openSystemNotificationShade();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        adminDialog.show();
    }

    /** Opens the normal Android notification shade (may be blocked on some devices / by device policy). */
    @SuppressLint({"WrongConstant", "PrivateApi"})
    private void openSystemNotificationShade() {
        try {
            Object statusBarService = getSystemService("statusbar");
            Class<?> statusBarManager = Class.forName("android.app.StatusBarManager");
            statusBarManager.getMethod("expandNotificationsPanel").invoke(statusBarService);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open the notification bar on this device", Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------
    // Quick panel (notification-style panel inside the launcher)
    // ------------------------------------------------------------------
    private void setupQuickPanel() {
        findViewById(R.id.panel_scrim).setOnClickListener(v -> hideQuickPanel());
        findViewById(R.id.panel_handle_area).setOnClickListener(v -> hideQuickPanel());

        SeekBar brightness = findViewById(R.id.panel_brightness);
        int current = 128;
        try {
            current = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException ignored) {
            // keep default
        }
        brightness.setProgress(current);
        brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    applyBrightness(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        findViewById(R.id.tile_silent).setOnClickListener(v -> openSettingsScreen(Settings.ACTION_SOUND_SETTINGS));
        findViewById(R.id.tile_rotation).setOnClickListener(v -> openSettingsScreen(Settings.ACTION_DISPLAY_SETTINGS));
        findViewById(R.id.tile_flight).setOnClickListener(v -> openSettingsScreen(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        findViewById(R.id.tile_flash).setOnClickListener(v -> toggleFlashlight());
        findViewById(R.id.tile_hotspot).setOnClickListener(v -> openHotspotSettings());
        findViewById(R.id.panel_bg_apps).setOnClickListener(v ->
                Toast.makeText(this, "Use the Recent apps button on the navigation bar", Toast.LENGTH_SHORT).show());
    }

    private void showQuickPanel() {
        if (quickPanel.getVisibility() == View.VISIBLE) {
            return;
        }
        quickPanel.setAlpha(0f);
        quickPanel.setVisibility(View.VISIBLE);
        quickPanel.animate().alpha(1f).setDuration(150).start();
    }

    private void hideQuickPanel() {
        quickPanel.animate().alpha(0f).setDuration(150)
                .withEndAction(() -> quickPanel.setVisibility(View.GONE)).start();
    }

    private void applyBrightness(int value) {
        int level = Math.max(value, 10);
        if (Settings.System.canWrite(this)) {
            // System-wide brightness (needs "Modify system settings" allowed for this app)
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, level);
            } catch (Exception ignored) {
                // fall through: nothing else to do
            }
        } else {
            // Without that permission only this screen's brightness can change
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = level / 255f;
            getWindow().setAttributes(lp);
        }
    }

    private void toggleFlashlight() {
        try {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String torchId = null;
            for (String id : cameraManager.getCameraIdList()) {
                Boolean hasFlash = cameraManager.getCameraCharacteristics(id)
                        .get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (hasFlash != null && hasFlash) {
                    torchId = id;
                    break;
                }
            }
            if (torchId == null) {
                Toast.makeText(this, "No flashlight on this device", Toast.LENGTH_SHORT).show();
                return;
            }
            torchOn = !torchOn;
            cameraManager.setTorchMode(torchId, torchOn);
        } catch (CameraAccessException | IllegalArgumentException | SecurityException e) {
            torchOn = false;
            Toast.makeText(this, "Flashlight unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void openHotspotSettings() {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.TetherSettings"));
            startActivity(intent);
        } catch (Exception e) {
            openSettingsScreen(Settings.ACTION_WIRELESS_SETTINGS);
        }
    }

    private void openSettingsScreen(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open settings", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // App shortcuts
    // ------------------------------------------------------------------
    private void setupShortcuts() {
        // 1. Brilliant Pala e-learning
        findViewById(R.id.btn_elearning).setOnClickListener(v -> launchApp(PACKAGE_ELEARNING));

        // 2. Brilliant Pala Classes
        findViewById(R.id.btn_classes).setOnClickListener(v -> launchApp(PACKAGE_CLASSES));

        // 3. Bluetooth Manager screen (inside this app)
        findViewById(R.id.btn_bluetooth).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, BluetoothActivity.class)));

        // 4. Clock
        findViewById(R.id.btn_clock).setOnClickListener(v -> {
            String clockPackage = getInstalledClockPackage(getPackageManager());
            if (clockPackage != null) {
                launchApp(clockPackage);
            } else {
                Toast.makeText(MainActivity.this, "Clock app not found", Toast.LENGTH_SHORT).show();
            }
        });

        // 5. Brilliant Pala e-library: opens the app, or its Play Store page if not installed
        findViewById(R.id.btn_elibrary).setOnClickListener(v -> openElibrary());

        refreshInstalledAppIcons();
    }

    /** Shows the real icon for apps that are installed (Clock, e-library). */
    private void refreshInstalledAppIcons() {
        PackageManager pm = getPackageManager();

        String clockPackage = getInstalledClockPackage(pm);
        if (clockPackage != null) {
            loadAppIcon(pm, clockPackage, findViewById(R.id.img_clock));
        }

        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            loadAppIcon(pm, PACKAGE_ELIBRARY, findViewById(R.id.img_elibrary));
        } else {
            ((ImageView) findViewById(R.id.img_elibrary)).setImageResource(R.drawable.icon_elibrary);
        }
    }

    private void loadAppIcon(PackageManager pm, String packageName, ImageView imageView) {
        try {
            Drawable icon = pm.getApplicationIcon(packageName);
            imageView.setImageDrawable(icon);
        } catch (PackageManager.NameNotFoundException e) {
            // Keep the placeholder icon declared in the layout
        }
    }

    private void openElibrary() {
        PackageManager pm = getPackageManager();
        if (isPackageInstalled(pm, PACKAGE_ELIBRARY)) {
            launchApp(PACKAGE_ELIBRARY);
            return;
        }
        try {
            // Opens the Play Store app directly on the e-library page
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + PACKAGE_ELIBRARY)));
        } catch (ActivityNotFoundException e) {
            try {
                // No Play Store app: fall back to the web link
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ELIBRARY_PLAY_URL)));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "Play Store not available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void launchApp(String packageName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) {
            Toast.makeText(this, "Application not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Unable to open application", Toast.LENGTH_SHORT).show();
        }
    }

    private String getInstalledClockPackage(PackageManager pm) {
        if (isPackageInstalled(pm, PACKAGE_GOOGLE_CLOCK)) {
            return PACKAGE_GOOGLE_CLOCK;
        } else if (isPackageInstalled(pm, PACKAGE_AOSP_CLOCK)) {
            return PACKAGE_AOSP_CLOCK;
        }
        return null;
    }

    private boolean isPackageInstalled(PackageManager pm, String packageName) {
        try {
            pm.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
