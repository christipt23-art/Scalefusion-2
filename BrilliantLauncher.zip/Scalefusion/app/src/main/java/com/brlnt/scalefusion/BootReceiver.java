package com.brlnt.scalefusion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Puts the alarms back after a restart, an app update or a time change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmScheduler.rescheduleAll(context);
    }
}
