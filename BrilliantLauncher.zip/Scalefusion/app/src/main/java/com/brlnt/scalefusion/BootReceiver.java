package com.brlnt.scalefusion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Puts the alarms back after a restart, an app update or a time change, and (after a restart or
 * update) puts the status-bar block back before the launcher is even opened.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmScheduler.rescheduleAll(context);
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            KioskUtils.showBlocker(context);
            KioskUtils.enterQuietMode(context);
            KioskUtils.disableStatusBarIfOwner(context);
        }
    }
}
