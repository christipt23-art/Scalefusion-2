package com.brlnt.scalefusion;

import android.content.Context;
import android.content.SharedPreferences;

/** Keeps the countdown timer alive while the Time screen is closed. */
final class TimerState {
    static final int IDLE = 0;
    static final int RUNNING = 1;
    static final int PAUSED = 2;

    private static final String PREFS = "time_timer";

    private TimerState() {
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int state(Context c) {
        return p(c).getInt("state", IDLE);
    }

    static long endMs(Context c) {
        return p(c).getLong("end", 0);
    }

    static long remainingMs(Context c) {
        if (state(c) == RUNNING) {
            return Math.max(0, endMs(c) - System.currentTimeMillis());
        }
        return p(c).getLong("remaining", 0);
    }

    static void start(Context c, long totalMs) {
        long end = System.currentTimeMillis() + totalMs;
        p(c).edit().putInt("state", RUNNING).putLong("end", end).apply();
        AlarmScheduler.scheduleTimer(c, end);
    }

    static void pause(Context c) {
        long remaining = remainingMs(c);
        p(c).edit().putInt("state", PAUSED).putLong("remaining", remaining).apply();
        AlarmScheduler.cancelTimer(c);
    }

    static void resume(Context c) {
        long remaining = p(c).getLong("remaining", 0);
        long end = System.currentTimeMillis() + remaining;
        p(c).edit().putInt("state", RUNNING).putLong("end", end).apply();
        AlarmScheduler.scheduleTimer(c, end);
    }

    static void reset(Context c) {
        p(c).edit().putInt("state", IDLE).apply();
        AlarmScheduler.cancelTimer(c);
    }
}
