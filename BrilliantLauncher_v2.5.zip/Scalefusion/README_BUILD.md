# Brilliant Launcher (v2.5) - how to build the APK

## Option A: Android Studio (easiest)
1. Unzip, then in Android Studio choose **File > Open** and select the `Scalefusion` folder.
2. Wait for "Gradle sync" to finish (needs internet the first time, JDK 17 or newer - the one bundled with Android Studio is fine).
3. **Build > Generate App Bundles or APKs > Generate APKs** (or **Build > Generate Signed App Bundle / APK > APK**
   and pick `app/release.jks`, alias `brilliant`, passwords are in `app/build.gradle.kts`).
4. Click "locate" in the pop-up. The file is `app/build/outputs/apk/release/app-release.apk`.

## Option B: command line
    cd Scalefusion
    ./gradlew assembleRelease          (Windows: gradlew.bat assembleRelease)
APK: `app/build/outputs/apk/release/app-release.apk`

## Install on the tablet
    adb install -r app-release.apk
(or copy the APK to the tablet and open it). It is signed with the same key as before, so it updates the old version.

## First run on the tablet
* Tap **Allow** on "Display over other apps" - this is what blocks the Android notification bar.
* Brightness slider / rotation tile: Settings > Apps > Brilliant Launcher > Modify system settings > Allow.
* Allow Notifications (Android 13+) so alarms/timers can show.

## Blocking the notification bar, quick settings and the Recents (square) button
Without device-owner mode these are best-effort (Android does not let a normal app remove them):
* a transparent overlay swallows swipes on the status-bar strip,
* if the shade still opens it is collapsed again,
* if Recents is opened the launcher is brought straight back.

For a guaranteed block make the app "device owner" (tablet must have no Google/other accounts, or be freshly reset),
then run once:
    adb shell dpm set-device-owner com.brlnt.scalefusion/.KioskAdminReceiver
The launcher then switches the status bar, notification shade, quick settings and the Recents button off through
Android itself (lock-task mode, only Home stays), and gives them back when you Exit. Apps it may open in that mode are
listed in `LOCK_TASK_EXTRA_PACKAGES` in `KioskUtils.java`.

## Admin menu (tap the title 6 times, enter the password)
Open Settings, Control Panel (shortcuts to the Android settings pages), App List, Notification, Default Home Screen (this launcher or Scalefusion) and Change Password.
"Notification" opens the real Android notification bar once; the blocking switches back on as soon as it is closed.

## No notifications
On first run tap **Allow** on "Do Not Disturb access". The launcher then keeps the tablet in "alarms only":
no notification pops up, lights the screen or makes a sound. Alarms/timers from the Time app still ring.
Exit puts the previous setting back.

## Control center
Swipe down from the top edge, or drag (or tap) the arrow at the bottom right, to bring it down from the top-middle.
Tap anywhere outside the brightness bar, swipe it up or press Back to close it.
Only the brightness bar works; the tiles are display only and "View Background Apps" does nothing.

## Where to change things
* Password: each device asks for its own password (3-8 digits) the first time the app is opened; change it from the admin menu > Change Password (logic in `PasscodeStore.java`)
* Icons: `res/drawable/icon_time.png`, `icon_bluetooth.png`, `icon_classes.png`
* Backgrounds: `res/drawable/bg_image.jpg` (portrait), `res/drawable-land/bg_image.jpg` (landscape)
* Status bar: `CustomStatusBar.java` (colour `status_bar_bg`); toolbar colour `toolbar_blue`; control center: `res/layout/layout_quick_panel.xml`
* Home icon size / spacing: `applyHomeMetrics()` in `MainActivity.java` (icon = 7.4% of screen width)
* Time app: `TimeActivity.java` + `res/layout/*time*.xml`; blue colour = `time_blue` in `res/values/colors.xml`
